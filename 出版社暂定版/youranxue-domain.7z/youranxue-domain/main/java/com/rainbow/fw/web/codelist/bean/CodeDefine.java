package com.rainbow.fw.web.codelist.bean;

public interface CodeDefine {
	String getCodeName();

	String getCodeKey();

	String getCodeValue();

	void setCodeName(String codeName);

	void setCodeKey(String codeKey);

	void setCodeValue(String codeValue);
}
