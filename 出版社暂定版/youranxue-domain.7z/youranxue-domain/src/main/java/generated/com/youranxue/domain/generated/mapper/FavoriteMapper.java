﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.Favorite;

public interface FavoriteMapper {
	List<Favorite> getFavoriteList();
	int insert(Favorite favorite);
	Favorite readByPk(Favorite favorite);
	int update(Favorite favorite);
	int delete(Favorite favorite);
}