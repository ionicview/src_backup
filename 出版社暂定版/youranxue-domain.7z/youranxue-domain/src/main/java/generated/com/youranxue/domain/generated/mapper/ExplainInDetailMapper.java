﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.ExplainInDetail;

public interface ExplainInDetailMapper {
	List<ExplainInDetail> getExplainInDetailList();
	int insert(ExplainInDetail explainindetail);
	ExplainInDetail readByPk(ExplainInDetail explainindetail);
	int update(ExplainInDetail explainindetail);
	int delete(ExplainInDetail explainindetail);
}