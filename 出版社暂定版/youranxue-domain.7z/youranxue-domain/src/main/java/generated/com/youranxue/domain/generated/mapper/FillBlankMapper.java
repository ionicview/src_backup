﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.FillBlank;

public interface FillBlankMapper {
	List<FillBlank> getFillBlankList();
	int insert(FillBlank fillblank);
	FillBlank readByPk(FillBlank fillblank);
	int update(FillBlank fillblank);
	int delete(FillBlank fillblank);
}