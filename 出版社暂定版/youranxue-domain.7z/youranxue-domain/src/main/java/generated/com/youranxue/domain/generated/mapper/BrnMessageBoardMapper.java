﻿package com.youranxue.domain.generated.mapper;
import java.util.List;

import com.youranxue.domain.generated.record.BrnMessageBoard;

public interface BrnMessageBoardMapper {
	List<BrnMessageBoard> getBrnMessageBoardList();
	int insert(BrnMessageBoard brnmessageboard);
	BrnMessageBoard readByPk(BrnMessageBoard brnmessageboard);
	int update(BrnMessageBoard brnmessageboard);
	int delete(BrnMessageBoard brnmessageboard);
}