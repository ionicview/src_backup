﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class CodeTypeMst implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 代码类别ID */
	protected long codeTypeId;
	/** 代码英文名称 */
	protected String physicalName;
	/** 代码中文名称 */
	protected String logicName;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}