﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.Choice;

public interface ChoiceMapper {
	List<Choice> getChoiceList();
	int insert(Choice choice);
	Choice readByPk(Choice choice);
	int update(Choice choice);
	int delete(Choice choice);
}