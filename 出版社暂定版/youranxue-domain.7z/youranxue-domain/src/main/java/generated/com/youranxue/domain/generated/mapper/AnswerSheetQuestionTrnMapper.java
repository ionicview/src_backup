﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.AnswerSheetQuestionTrn;

public interface AnswerSheetQuestionTrnMapper {
	List<AnswerSheetQuestionTrn> getAnswerSheetQuestionTrnList();
	int insert(AnswerSheetQuestionTrn answersheetquestiontrn);
	AnswerSheetQuestionTrn readByPk(AnswerSheetQuestionTrn answersheetquestiontrn);
	int update(AnswerSheetQuestionTrn answersheetquestiontrn);
	int delete(AnswerSheetQuestionTrn answersheetquestiontrn);
}