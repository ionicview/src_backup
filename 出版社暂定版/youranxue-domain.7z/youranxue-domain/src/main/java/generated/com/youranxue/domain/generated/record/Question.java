﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class Question implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 题目ID */
	protected long questionId;
	/** 题目类型ID */
	protected long questionTypeId;
	/** 题干 */
	protected String question;
	/** 图片路径 */
	protected String imgPath;
	/** 节ID */
	protected long sectionId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}