﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.SubjectMst;

public interface SubjectMstMapper {
	List<SubjectMst> getSubjectMstList();
	int insert(SubjectMst subjectmst);
	SubjectMst readByPk(SubjectMst subjectmst);
	int update(SubjectMst subjectmst);
	int delete(SubjectMst subjectmst);
}