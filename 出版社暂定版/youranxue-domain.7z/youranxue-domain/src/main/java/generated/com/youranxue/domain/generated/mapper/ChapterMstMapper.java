﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.ChapterMst;

public interface ChapterMstMapper {
	List<ChapterMst> getChapterMstList();
	int insert(ChapterMst chaptermst);
	ChapterMst readByPk(ChapterMst chaptermst);
	int update(ChapterMst chaptermst);
	int delete(ChapterMst chaptermst);
}