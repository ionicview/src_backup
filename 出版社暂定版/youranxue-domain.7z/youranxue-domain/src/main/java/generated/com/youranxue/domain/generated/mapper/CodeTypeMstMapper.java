﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.CodeTypeMst;

public interface CodeTypeMstMapper {
	List<CodeTypeMst> getCodeTypeMstList();
	int insert(CodeTypeMst codetypemst);
	CodeTypeMst readByPk(CodeTypeMst codetypemst);
	int update(CodeTypeMst codetypemst);
	int delete(CodeTypeMst codetypemst);
}