﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.AnswerSheetTrn;

public interface AnswerSheetTrnMapper {
	List<AnswerSheetTrn> getAnswerSheetTrnList();
	int insert(AnswerSheetTrn answersheettrn);
	AnswerSheetTrn readByPk(AnswerSheetTrn answersheettrn);
	int update(AnswerSheetTrn answersheettrn);
	int delete(AnswerSheetTrn answersheettrn);
}