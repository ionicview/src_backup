﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class BookMst implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 教材ID */
	protected long bookId;
	/** 年级ID */
	protected long gradeId;
	/** 教材名称 */
	protected String bookName;
	/** ISBN */
	protected String isbn;
	/** 学科ID */
	protected long subjectId;
	/** 学期ID */
	protected long semesterId;
	/** 出版社ID */
	protected long publisherId;
	/** 封面图片ID */
	protected long imgId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}