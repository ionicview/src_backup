﻿package com.youranxue.domain.generated.mapper;
import java.util.List;

import com.youranxue.domain.generated.record.BrnNews;

public interface BrnNewsMapper {
	List<BrnNews> getBrnNewsList();
	int insert(BrnNews brnnews);
	BrnNews readByPk(BrnNews brnnews);
	int update(BrnNews brnnews);
	int delete(BrnNews brnnews);
}