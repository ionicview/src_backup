﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.QuestionTypeMst;

public interface QuestionTypeMstMapper {
	List<QuestionTypeMst> getQuestionTypeMstList();
	int insert(QuestionTypeMst questiontypemst);
	QuestionTypeMst readByPk(QuestionTypeMst questiontypemst);
	int update(QuestionTypeMst questiontypemst);
	int delete(QuestionTypeMst questiontypemst);
}