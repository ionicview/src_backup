﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.QuestionKnowledge;

public interface QuestionKnowledgeMapper {
	List<QuestionKnowledge> getQuestionKnowledgeList();
	int insert(QuestionKnowledge questionknowledge);
	QuestionKnowledge readByPk(QuestionKnowledge questionknowledge);
	int update(QuestionKnowledge questionknowledge);
	int delete(QuestionKnowledge questionknowledge);
}