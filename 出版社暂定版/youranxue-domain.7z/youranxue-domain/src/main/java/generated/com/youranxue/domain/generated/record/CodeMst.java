﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class CodeMst implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 代码ID */
	protected long codeId;
	/** 代码键 */
	protected String codeKey;
	/** 代码值 */
	protected String codeValue;
	/** 说明 */
	protected String note;
	/** 代码类别ID */
	protected long codeTypeId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}