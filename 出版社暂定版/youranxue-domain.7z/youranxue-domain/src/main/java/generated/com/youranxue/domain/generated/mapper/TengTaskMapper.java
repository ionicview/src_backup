﻿package com.youranxue.domain.generated.mapper;
import java.util.List;

import com.youranxue.domain.generated.record.TengTask;

public interface TengTaskMapper {
	List<TengTask> getTengTaskList();
	int insert(TengTask tengtask);
	TengTask readByPk(TengTask tengtask);
	int update(TengTask tengtask);
	int delete(TengTask tengtask);
}