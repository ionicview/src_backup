﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.ImgMst;

public interface ImgMstMapper {
	List<ImgMst> getImgMstList();
	int insert(ImgMst imgmst);
	ImgMst readByPk(ImgMst imgmst);
	int update(ImgMst imgmst);
	int delete(ImgMst imgmst);
}