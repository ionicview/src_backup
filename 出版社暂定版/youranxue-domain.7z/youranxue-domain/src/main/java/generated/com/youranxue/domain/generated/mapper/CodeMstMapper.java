﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.CodeMst;

public interface CodeMstMapper {
	List<CodeMst> getCodeMstList();
	int insert(CodeMst codemst);
	CodeMst readByPk(CodeMst codemst);
	int update(CodeMst codemst);
	int delete(CodeMst codemst);
}