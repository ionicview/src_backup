﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class ChapterMst implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 章ID */
	protected long chapterId;
	/** 章名称 */
	protected String chapterName;
	/** 教材ID */
	protected long bookId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}