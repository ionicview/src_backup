﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.MyBooks;

public interface MyBooksMapper {
	List<MyBooks> getMyBooksList();
	int insert(MyBooks mybooks);
	MyBooks readByPk(MyBooks mybooks);
	int update(MyBooks mybooks);
	int delete(MyBooks mybooks);
}