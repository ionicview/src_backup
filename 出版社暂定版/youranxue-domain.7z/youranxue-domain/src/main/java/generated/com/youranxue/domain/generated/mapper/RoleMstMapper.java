﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.RoleMst;

public interface RoleMstMapper {
	List<RoleMst> getRoleMstList();
	int insert(RoleMst rolemst);
	RoleMst readByPk(RoleMst rolemst);
	int update(RoleMst rolemst);
	int delete(RoleMst rolemst);
}