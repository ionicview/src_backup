﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.BookMst;

public interface BookMstMapper {
	List<BookMst> getBookMstList();
	int insert(BookMst bookmst);
	BookMst readByPk(BookMst bookmst);
	int update(BookMst bookmst);
	int delete(BookMst bookmst);
}