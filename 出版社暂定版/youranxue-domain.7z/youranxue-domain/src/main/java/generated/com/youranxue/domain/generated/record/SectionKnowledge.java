﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class SectionKnowledge implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 知识点ID */
	protected long knowledgeId;
	/** 节ID */
	protected long sectionId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}