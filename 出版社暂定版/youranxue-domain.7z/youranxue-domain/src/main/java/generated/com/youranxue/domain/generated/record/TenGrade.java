﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class TenGrade implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/**年级ID*/
	protected String gradeId;
	/**年级名*/
	protected String gradeName;
	/**创建时间*/
	protected Date createDate;
	/**更新时间*/
	protected Date updateDate;
	/**删除标记*/
	protected int delFlg;
}