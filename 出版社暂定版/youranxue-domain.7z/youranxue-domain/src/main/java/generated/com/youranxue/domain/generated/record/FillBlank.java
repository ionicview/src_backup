﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class FillBlank implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 填空题空白ID */
	protected long fillBlankId;
	/** 序号 */
	protected int sequenceNum;
	/** 正确答案 */
	protected String answer;
	/** 题目ID */
	protected long questionId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}