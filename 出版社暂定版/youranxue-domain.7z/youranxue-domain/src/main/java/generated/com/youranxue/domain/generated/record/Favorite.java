﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class Favorite implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 收藏ID */
	protected long favoriteId;
	/** 收藏分类ID */
	protected long favoriteTypeId;
	/** 题目ID */
	protected long questionId;
	/** 用户ID */
	protected String userId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}