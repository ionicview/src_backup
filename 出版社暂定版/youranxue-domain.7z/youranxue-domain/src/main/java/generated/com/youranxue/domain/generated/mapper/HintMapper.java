﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.Hint;

public interface HintMapper {
	List<Hint> getHintList();
	int insert(Hint hint);
	Hint readByPk(Hint hint);
	int update(Hint hint);
	int delete(Hint hint);
}