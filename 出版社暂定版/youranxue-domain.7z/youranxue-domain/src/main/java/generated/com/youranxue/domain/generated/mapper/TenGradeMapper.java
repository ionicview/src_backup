﻿package com.youranxue.domain.generated.mapper;
import java.util.List;

import com.youranxue.domain.generated.record.TenGrade;

public interface TenGradeMapper {
	List<TenGrade> getTenGradeList();
	int insert(TenGrade tengrade);
	TenGrade readByPk(TenGrade tengrade);
	int update(TenGrade tengrade);
	int delete(TenGrade tengrade);
}