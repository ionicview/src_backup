﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.util.Date;
@Data
public class ShortAnswer implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 问答题详细ID */
	protected long shortAnswerId;
	/** 序号 */
	protected int sequenceNum;
	/** 问答内容 */
	protected String shortAnswerContent;
	/** 正确答案 */
	protected String answer;
	/** 图片路径 */
	protected String imgPath;
	/** 题目ID */
	protected long questionId;
	/** 创建日期 */
	protected Date createDate;
	/** 更新日期 */
	protected Date updateDate;
	/** 更新者 */
	protected String updateUser;
	/** 删除标记 */
	protected int delFlg;
}