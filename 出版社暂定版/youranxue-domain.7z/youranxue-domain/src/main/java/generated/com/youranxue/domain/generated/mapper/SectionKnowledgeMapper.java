﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.SectionKnowledge;

public interface SectionKnowledgeMapper {
	List<SectionKnowledge> getSectionKnowledgeList();
	int insert(SectionKnowledge sectionknowledge);
	SectionKnowledge readByPk(SectionKnowledge sectionknowledge);
	int update(SectionKnowledge sectionknowledge);
	int delete(SectionKnowledge sectionknowledge);
}