﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.Question;

public interface QuestionMapper {
	List<Question> getQuestionList();
	int insert(Question question);
	Question readByPk(Question question);
	int update(Question question);
	int delete(Question question);
}