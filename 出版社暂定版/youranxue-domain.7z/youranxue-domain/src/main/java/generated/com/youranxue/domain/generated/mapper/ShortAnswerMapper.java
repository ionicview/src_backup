﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.ShortAnswer;

public interface ShortAnswerMapper {
	List<ShortAnswer> getShortAnswerList();
	int insert(ShortAnswer shortanswer);
	ShortAnswer readByPk(ShortAnswer shortanswer);
	int update(ShortAnswer shortanswer);
	int delete(ShortAnswer shortanswer);
}