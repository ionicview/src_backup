﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.SectionMst;

public interface SectionMstMapper {
	List<SectionMst> getSectionMstList();
	int insert(SectionMst sectionmst);
	SectionMst readByPk(SectionMst sectionmst);
	int update(SectionMst sectionmst);
	int delete(SectionMst sectionmst);
}