﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.UserMst;

public interface UserMstMapper {
	List<UserMst> getUserMstList();
	int insert(UserMst usermst);
	UserMst readByPk(UserMst usermst);
	int update(UserMst usermst);
	int delete(UserMst usermst);
}