﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.FavoriteType;

public interface FavoriteTypeMapper {
	List<FavoriteType> getFavoriteTypeList();
	int insert(FavoriteType favoritetype);
	FavoriteType readByPk(FavoriteType favoritetype);
	int update(FavoriteType favoritetype);
	int delete(FavoriteType favoritetype);
}