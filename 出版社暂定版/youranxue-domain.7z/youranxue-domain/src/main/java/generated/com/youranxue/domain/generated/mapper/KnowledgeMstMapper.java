﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.KnowledgeMst;

public interface KnowledgeMstMapper {
	List<KnowledgeMst> getKnowledgeMstList();
	int insert(KnowledgeMst knowledgemst);
	KnowledgeMst readByPk(KnowledgeMst knowledgemst);
	int update(KnowledgeMst knowledgemst);
	int delete(KnowledgeMst knowledgemst);
}