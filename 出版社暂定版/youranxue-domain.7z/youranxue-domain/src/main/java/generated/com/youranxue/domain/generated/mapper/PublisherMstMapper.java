﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.PublisherMst;

public interface PublisherMstMapper {
	List<PublisherMst> getPublisherMstList();
	int insert(PublisherMst publishermst);
	PublisherMst readByPk(PublisherMst publishermst);
	int update(PublisherMst publishermst);
	int delete(PublisherMst publishermst);
}