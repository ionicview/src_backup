﻿package com.youranxue.domain.generated.record;
import java.io.Serializable;
import lombok.Data;
import java.math.BigDecimal;import java.util.Date;
@Data
public class TengTask implements Serializable{
	/** SerialVersion */
	private static final long serialVersionUID = 1L;
	/** 作业ID */
	protected long taskId;
	/** 作业名称 */
	protected String taskName;
	/** 作业总分 */
	protected BigDecimal totalScore;
	/** 创建时间 */
	protected Date createDate;
	/** 更新时间 */
	protected Date updateDate;
	/** 删除标记 */
	protected int delFlg;
}