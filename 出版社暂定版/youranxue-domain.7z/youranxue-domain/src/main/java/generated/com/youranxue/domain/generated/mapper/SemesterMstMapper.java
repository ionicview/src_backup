﻿package com.youranxue.domain.generated.mapper;
import java.util.List;
import com.youranxue.domain.generated.record.SemesterMst;

public interface SemesterMstMapper {
	List<SemesterMst> getSemesterMstList();
	int insert(SemesterMst semestermst);
	SemesterMst readByPk(SemesterMst semestermst);
	int update(SemesterMst semestermst);
	int delete(SemesterMst semestermst);
}