package com.youranxue.domain.vo;

import java.util.ArrayList;
import java.util.List;

import com.youranxue.domain.generated.record.BrnNews;

import lombok.Data;

@Data
public class HomeContents {

	/** 首页主图 */
	private String sliderFile;

	/** 首页辅图 */
	private String homeSubImgFile;

	/** 简讯 */
	private BrnNews newsletter;

	/** 新闻 */
	private List<BrnNews> newsList = new ArrayList<BrnNews>();

	private List<ProductDetail> productDetailList = new ArrayList<ProductDetail>();

	public void addNews(List<BrnNews> newsList) {
		this.newsList.addAll(newsList);
	}

	public void addProduct(ProductDetail productDetail) {
		this.productDetailList.add(productDetail);
	}

	public void addProductList(List<ProductDetail> productDetailList) {
		this.productDetailList.addAll(productDetailList);
	}

}
