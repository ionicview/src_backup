package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.BrnImage;

public interface ImageEntityMapper {

	List<BrnImage> getImageListById(int id);

}
