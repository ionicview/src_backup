package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.BrnOrder;
import com.youranxue.domain.vo.ProductDetail;

public interface OrderEntityMapper {
	List<ProductDetail> getOrderedProductDetailList(long orderId);

	long insert(BrnOrder brnOrder);

	List<BrnOrder> getRecords(BrnOrder order);
}
