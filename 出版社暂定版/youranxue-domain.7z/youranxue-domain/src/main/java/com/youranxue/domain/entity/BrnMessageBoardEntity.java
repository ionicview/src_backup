package com.youranxue.domain.entity;

import com.youranxue.domain.generated.base.BrnMessageBoardBase;
import com.youranxue.domain.stereotype.Entity;

@Entity
@SuppressWarnings("serial")
public class BrnMessageBoardEntity extends BrnMessageBoardBase {

}
