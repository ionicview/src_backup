package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.rainbow.fw.web.context.WebApplicationContext;
import com.youranxue.domain.entity.mapper.TengTaskEntityMapper;
import com.youranxue.domain.generated.base.TengTaskBase;
import com.youranxue.domain.generated.record.TengTask;
import com.youranxue.domain.stereotype.Entity;

@Entity
@SuppressWarnings("serial")
public class TengTaskEntity extends TengTaskBase {

	@Autowired
	private WebApplicationContext appContext;

	@Autowired
	private TengTaskEntityMapper TengTaskEntityMapper;

	public List<TengTask> getAllTengTaskList() {

		return TengTaskEntityMapper.getRecords(this);

	}

}
