package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.youranxue.domain.entity.mapper.NewsEntityMapper;
import com.youranxue.domain.generated.base.BrnNewsBase;
import com.youranxue.domain.generated.record.BrnNews;
import com.youranxue.domain.stereotype.Entity;

@Entity
@SuppressWarnings("serial")
public class BrnNewsEntity extends BrnNewsBase {

	@Autowired
	private NewsEntityMapper newsEntityMapper;

	public List<BrnNews> readHomeNews() {
		return newsEntityMapper.readHomeNews();
	}
}
