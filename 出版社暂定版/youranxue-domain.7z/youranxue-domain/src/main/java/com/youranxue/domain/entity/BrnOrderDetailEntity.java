package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import sun.reflect.ReflectionFactory.GetReflectionFactoryAction;

import com.youranxue.domain.entity.mapper.OrderDetailEntityMapper;
import com.youranxue.domain.generated.base.BrnOrderDetailBase;
import com.youranxue.domain.stereotype.Entity;
import com.youranxue.domain.vo.ProductDetail;

@Entity
@SuppressWarnings("serial")
public class BrnOrderDetailEntity extends BrnOrderDetailBase {

	@Autowired
	private OrderDetailEntityMapper orderDetailEntityMapper;
	

	

}
