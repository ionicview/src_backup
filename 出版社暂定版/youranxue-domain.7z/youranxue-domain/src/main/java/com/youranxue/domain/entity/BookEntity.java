package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.youranxue.domain.entity.mapper.BookEntityMapper;
import com.youranxue.domain.generated.base.BookBase;
import com.youranxue.domain.stereotype.Entity;
import com.youranxue.domain.vo.Book;

@Entity
@SuppressWarnings("serial")
public class BookEntity extends BookBase {

	@Autowired
	private BookEntityMapper bookEntityMapper;

	public List<Book> searchMyBookList(String userId) {
		return bookEntityMapper.searchMyBookList(userId);
	}
}
