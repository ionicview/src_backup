package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.TenGrade;

public interface TenGradeEntityMapper {
	List<TenGrade> getRecords(TenGrade tenGrade);

}
