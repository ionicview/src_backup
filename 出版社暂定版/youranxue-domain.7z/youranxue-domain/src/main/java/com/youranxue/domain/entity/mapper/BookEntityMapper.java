package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.vo.Book;

public interface BookEntityMapper {
	List<Book> searchMyBookList(String userId);
}
