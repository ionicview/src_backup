package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.BrnUserDetail;

public interface UserDetailEntityMapper {
	List<BrnUserDetail> getRecords(BrnUserDetail brnUserDetail);

}
