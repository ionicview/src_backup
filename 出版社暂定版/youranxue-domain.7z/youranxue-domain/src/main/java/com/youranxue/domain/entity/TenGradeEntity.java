package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.rainbow.fw.web.context.WebApplicationContext;
import com.youranxue.domain.entity.mapper.TenGradeEntityMapper;
import com.youranxue.domain.generated.base.TenGradeBase;
import com.youranxue.domain.generated.record.TenGrade;
import com.youranxue.domain.stereotype.Entity;

@Entity
@SuppressWarnings("serial")
public class TenGradeEntity extends TenGradeBase {

	@Autowired
	private WebApplicationContext appContext;

	@Autowired
	private TenGradeEntityMapper tenGradeEntityMapper;

	public List<TenGrade> getAllTenGradeList() {

		return tenGradeEntityMapper.getRecords(this);

	}

}
