package com.youranxue.domain.service.base;

import com.rainbow.fw.web.context.ContextProvider;
import com.youranxue.domain.entity.BrnCartDetailEntity;
import com.youranxue.domain.entity.BrnCartEntity;
import com.youranxue.domain.entity.BrnCategoryEntity;
import com.youranxue.domain.entity.BrnImageEntity;
import com.youranxue.domain.entity.BrnOrderDetailEntity;
import com.youranxue.domain.entity.BrnProductEntity;
import com.youranxue.domain.entity.BrnUserDetailEntity;
import com.youranxue.domain.entity.BrnUserEntity;

public class EntityFactory {

	public static BrnUserEntity newBrnUserEntity(String userId) {
		BrnUserEntity entity = ContextProvider.getBean(BrnUserEntity.class);
		entity.setUserId(userId);
		return entity;
	}

	public static BrnUserDetailEntity newBrnUserDetailEntity(long addressId) {
		BrnUserDetailEntity entity = ContextProvider.getBean(BrnUserDetailEntity.class);
		entity.setAddressId(addressId);
		return entity;
	}

	public static BrnCategoryEntity newBrnCategoryEntity(long categoryId) {
		BrnCategoryEntity entity = ContextProvider.getBean(BrnCategoryEntity.class);
		// System.out.println("CG:"+categoryId);
		entity.setCategoryId(categoryId);
		return entity;
	}

	public static BrnProductEntity newBrnProductEntity(long productId) {
		BrnProductEntity entity = ContextProvider.getBean(BrnProductEntity.class);
		entity.setProductId(productId);
		return entity;
	}

	public static BrnImageEntity newBrnImageEntity(long imageId) {
		BrnImageEntity entity = ContextProvider.getBean(BrnImageEntity.class);
		entity.setImageId(imageId);
		return entity;
	}

	public static BrnImageEntity newBrnImageEntity() {

		return ContextProvider.getBean(BrnImageEntity.class);

	}

	public static BrnCartEntity newBrnCartEntity() {

		return ContextProvider.getBean(BrnCartEntity.class);

	}

	public static BrnCartEntity newBrnCartEntity(String cartId) {

		BrnCartEntity entity = ContextProvider.getBean(BrnCartEntity.class);
		entity.setCartId(cartId);
		return entity;

	}

	public static BrnCartDetailEntity newBrnCartDetailEntity(String cartId, long productId) {

		BrnCartDetailEntity entity = ContextProvider.getBean(BrnCartDetailEntity.class);

		entity.setCartId(cartId);
		entity.setProductId(productId);

		return entity;
	}

	public static BrnCartDetailEntity newBrnCartDetailEntity() {

		BrnCartDetailEntity entity = ContextProvider.getBean(BrnCartDetailEntity.class);

		return entity;
	}

	public static BrnOrderDetailEntity newBrnOrderDetailEntity() {
		BrnOrderDetailEntity entity = ContextProvider.getBean(BrnOrderDetailEntity.class);

		return entity;
	}

	public static <T> T newEntity(Class<T> cls) {
		T entity = ContextProvider.getBean(cls);

		return entity;
	}
}
