package com.youranxue.domain.security;

import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.InteractiveAuthenticationSuccessEvent;
import org.springframework.security.core.userdetails.UserDetails;

import com.youranxue.domain.entity.BrnUserEntity;
import com.youranxue.domain.service.base.EntityFactory;

public class AuthenticationSuccessListenerImpl implements ApplicationListener<InteractiveAuthenticationSuccessEvent> {

	public void onAuthenticationFailed(AbstractAuthenticationFailureEvent event) {
		// TODO Auto-generated method stub

	}

	public void onApplicationEvent(InteractiveAuthenticationSuccessEvent event) {
		// TODO Auto-generated method stub
		UserDetails userDetails = (UserDetails) event.getAuthentication().getPrincipal();
		BrnUserEntity userEntity = EntityFactory.newBrnUserEntity(userDetails.getUsername());
		userEntity.getEntityByPk();

	}

}
