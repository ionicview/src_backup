package com.youranxue.domain.entity.mapper;

public interface OrderDetailEntityMapper {
	void insert();

	
}
