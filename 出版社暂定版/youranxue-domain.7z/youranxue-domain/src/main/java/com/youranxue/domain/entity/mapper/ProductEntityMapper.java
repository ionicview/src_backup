package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.BrnImage;
import com.youranxue.domain.vo.ProductDetail;

public interface ProductEntityMapper {

	List<BrnImage> getAllImages(long productId);

	public List<ProductDetail> getRecommendedProduct(int count);
}
