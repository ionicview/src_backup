package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.youranxue.domain.entity.mapper.CategoryEntityMapper;
import com.youranxue.domain.generated.base.BrnCategoryBase;
import com.youranxue.domain.stereotype.Entity;
import com.youranxue.domain.vo.CategoryDetail;
import com.youranxue.domain.vo.Products;

@Entity
@SuppressWarnings("serial")
public class BrnCategoryEntity extends BrnCategoryBase {
	@Autowired
	private CategoryEntityMapper categoryEntityMapper;

	public List<CategoryDetail> getAllCategories() {
		return categoryEntityMapper.getAllCategories();
	}

	public Products getProducts() {
		super.getEntityByPk();
		Products products = new Products();
		products.setCategoryId(categoryId);
		products.setCategoryName(categoryName);
		products.addProduct(categoryEntityMapper.getAllProductsByCategoryId(categoryId));

		return products;

	}
}
