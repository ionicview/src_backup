package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.generated.record.BrnCart;
import com.youranxue.domain.vo.ProductDetail;

public interface CartEntityMapper {
	List<ProductDetail> getCartProductDetailList(String cartId);

	List<BrnCart> getRecords(BrnCart brnCart);
}
