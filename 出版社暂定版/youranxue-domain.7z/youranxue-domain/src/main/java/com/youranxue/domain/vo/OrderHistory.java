package com.youranxue.domain.vo;

import java.util.List;

import com.youranxue.domain.generated.record.BrnOrder;

import lombok.Data;

@Data
public class OrderHistory {
	BrnOrder brnOrder;
	List<ProductDetail> productDetailList;
}
