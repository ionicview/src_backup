package com.youranxue.domain.entity.mapper;

import java.util.List;

import com.youranxue.domain.vo.CategoryDetail;
import com.youranxue.domain.vo.ProductDetail;

public interface CategoryEntityMapper {
	List<CategoryDetail> getAllCategories();

	List<ProductDetail> getAllProductsByCategoryId(long categoryId);

}
