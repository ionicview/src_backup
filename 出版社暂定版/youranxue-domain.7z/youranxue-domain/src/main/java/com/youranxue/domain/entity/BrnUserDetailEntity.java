package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.youranxue.domain.entity.mapper.UserDetailEntityMapper;
import com.youranxue.domain.generated.base.BrnUserDetailBase;
import com.youranxue.domain.generated.record.BrnUserDetail;
import com.youranxue.domain.stereotype.Entity;

@Entity
@SuppressWarnings("serial")
public class BrnUserDetailEntity extends BrnUserDetailBase {

	@Autowired
	private UserDetailEntityMapper userDetailEntityMapper;

	public List<BrnUserDetail> getBrnUserDetailListByUserId(String userId) {
		this.userId = userId;
		return userDetailEntityMapper.getRecords(this);

	}
}
