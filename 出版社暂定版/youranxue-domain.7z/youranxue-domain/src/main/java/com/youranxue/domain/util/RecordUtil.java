package com.youranxue.domain.util;

public class RecordUtil {

	public static int NO_RECORD = 0;

	public static int ONE_RECORD = 1;

}
