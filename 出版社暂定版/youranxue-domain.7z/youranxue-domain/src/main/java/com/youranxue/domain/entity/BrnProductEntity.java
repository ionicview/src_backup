package com.youranxue.domain.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.youranxue.domain.entity.mapper.ProductEntityMapper;
import com.youranxue.domain.generated.base.BrnProductBase;
import com.youranxue.domain.generated.record.BrnImage;
import com.youranxue.domain.stereotype.Entity;
import com.youranxue.domain.vo.ProductDetail;

@Entity
@SuppressWarnings("serial")
public class BrnProductEntity extends BrnProductBase {

	@Autowired
	private ProductEntityMapper productEntityMapper;

	public List<BrnImage> getAllImages() {
		checkPkNotNull();
		return productEntityMapper.getAllImages(productId);
	}

	public List<ProductDetail> getRecommendedProduct(int topCount) {
		return productEntityMapper.getRecommendedProduct(topCount);
	}

}
