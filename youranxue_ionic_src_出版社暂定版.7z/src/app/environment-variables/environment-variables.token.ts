import { OpaqueToken } from "@angular/core";
export let EnvVariables = new OpaqueToken("env.variables");