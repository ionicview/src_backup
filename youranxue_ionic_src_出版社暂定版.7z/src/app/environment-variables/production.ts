export const prodVariables = {
  apiEndpoint: 'https://prod-endpoint.com',
  environmentName: 'Production Environment',
  ionicEnvName: 'prod'
};