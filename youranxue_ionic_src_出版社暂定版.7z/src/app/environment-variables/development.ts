
export const devVariables = {
  baseUrl: '/youranxue',
  imgBaseUrl: '/youranxue/image/imageDisplay',
  environmentName: 'Youranxue Environment',
  ionicEnvName: 'devEnv'
};