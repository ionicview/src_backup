package com.ironman.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ironman.domain.constant.HTTP;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.constant.URL;
import com.ironman.domain.service.IroAuthenticateService;
import com.ironman.domain.service.IroManagementService;

@CrossOrigin
@RestController
@RequestMapping(KEYWORD.MANAGEMENT)
public class ManagementController {

	@Autowired
	private IroManagementService iroManagementService;
	
	@Autowired
	private IroAuthenticateService iroAuthenticateService;
	
	@RequestMapping(value = URL.GET_USER_DATA, method = RequestMethod.GET)
	@ResponseBody
	public Map getUserData(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return null;
		}
		
		resp.setStatus(HttpServletResponse.SC_OK);
		
		return iroManagementService.getUserData(company_id);
	}
	
	
}
