package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroCustomerEntity;
import com.ironman.domain.generated.dto.IroCustomerMstDto;
import com.ironman.domain.repository.mapper.IroCustomerRepositoryMapper;
import com.rainbow.fw.core.factory.EntityFactory;



@Repository
public class IroCustomerRepository {
	@Autowired
	IroCustomerRepositoryMapper iroCustomerRepositoryMapper;
	
	public IroCustomerEntity findByPK(IroCustomerMstDto iroCustomerMstDto){
		IroCustomerEntity entity = EntityFactory.newEntity(IroCustomerEntity.class);
		IroCustomerMstDto result = iroCustomerRepositoryMapper.findByPK(iroCustomerMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
}
