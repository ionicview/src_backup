package com.ironman.domain.constant;

public class URL {
	
	final public static String GET_SALER_SUMMARY_SETTING = "getsalersummarysetting";
	final public static String GET_SALER_SUMMARY_DATA = "getsalersummarydata";
	final public static String GET_SALER_CUSTOMER_SUMMARY_SETTING = "getsalercustomersummarysetting";
	final public static String GET_SALER_CUSTOMER_SUMMARY_DATA = "getsalercustomersummarydata";
	final public static String GET_SALES_DETAIL_SETTING = "getsalesdetailsetting";
	final public static String GET_SALES_DETAIL_DATA = "getsalesdetaildata";
	
	final public static String GET_USER_DATA = "getuserdata";
	
	final public static String NEW_SALES = "newsales";
	final public static String UPDATE_SALES = "updatesales";
	final public static String DELETE_SALES = "deletesales";
	final public static String UPLOAD_PHOTOCOPY = "uploadphotocopy";



}
