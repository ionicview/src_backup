package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroJournalTrnDto;

public interface IroJournalEntityMapper {
	int save(IroJournalTrnDto iroJournalTrnDto);
	int update(IroJournalTrnDto iroJournalTrnDto);
	int delete(IroJournalTrnDto iroJournalTrnDto);
}
