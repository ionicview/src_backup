package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroOrderTrnDto;

public interface IroOrderEntityMapper {
	int save(IroOrderTrnDto iroOrderTrnDto);
	int update(IroOrderTrnDto iroOrderTrnDto);
	int delete(IroOrderTrnDto iroOrderTrnDto);
}
