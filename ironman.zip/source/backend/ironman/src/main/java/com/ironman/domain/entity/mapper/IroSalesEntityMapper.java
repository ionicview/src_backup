package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroSalesTrnDto;

public interface IroSalesEntityMapper {
	int save(IroSalesTrnDto iroSalesTrnDto);
	int update(IroSalesTrnDto iroSalesTrnDto);
	int delete(IroSalesTrnDto iroSalesTrnDto);
}
