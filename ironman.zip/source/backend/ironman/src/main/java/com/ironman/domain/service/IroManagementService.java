package com.ironman.domain.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.repository.IroUserRepository;

@Service
public class IroManagementService {
	
	@Autowired
	IroUserRepository iroUserRepository;
	
	public Map getUserData(String company_id){
		
	    List<IroUserEntity> records = findByCompany(company_id);
	    HashMap<String, Object> userDataMap = new HashMap<String,Object>();
	    userDataMap.put(KEYWORD.MANAGEMENT_USER_DATA, records);
	    return userDataMap;
		
		
	}
	
	public List findByCompany(String company_id){
		
		return iroUserRepository.findByCompany(company_id);
	}

}
