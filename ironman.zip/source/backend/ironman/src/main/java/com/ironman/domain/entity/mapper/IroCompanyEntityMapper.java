package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroCompanyMstDto;

public interface IroCompanyEntityMapper {
	int save(IroCompanyMstDto iroCompanyMstDto);
	int update(IroCompanyMstDto iroCompanyMstDto);
	int delete(IroCompanyMstDto iroCompanyMstDto);
}
