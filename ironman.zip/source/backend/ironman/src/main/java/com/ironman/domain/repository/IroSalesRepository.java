package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.generated.dto.IroSalesTrnDto;
import com.ironman.domain.repository.mapper.IroSalesRepositoryMapper;
import com.ironman.domain.service.result.IroSalesDetailCom;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroSalesRepository {
	
	@Autowired
	IroSalesRepositoryMapper iroSalesRepositoryMapper;
	
	public IroSalesEntity findByPK(IroSalesTrnDto iroSalesTrnDto){
		IroSalesEntity entity = EntityFactory.newEntity(IroSalesEntity.class);
		IroSalesTrnDto result = iroSalesRepositoryMapper.findByPK(iroSalesTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroSalesEntity findByPK(Long sales_id){
    	IroSalesTrnDto param = BeanFactory.newBean(IroSalesTrnDto.class);
    	param.setSales_id(sales_id);
    	return findByPK(param);
	}
	
	public Long findLastSeq(){
		return iroSalesRepositoryMapper.findLastSeq();
	}
	
	public boolean newEntity(IroSalesTrnDto iroSalesTrnDto){
		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
		iroSalesEntity.fromObject(iroSalesTrnDto);
		return iroSalesEntity.save();
	}
	
	public boolean newEntity(long sales_id, long order_id, long role_id, IroSalesDetailCom com){
		
		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
		iroSalesEntity.fromObject(com);
		iroSalesEntity.setSales_id(sales_id);
		iroSalesEntity.setOrder_id(order_id);
		iroSalesEntity.setEditor_role_id(role_id);
		calcArgItems(iroSalesEntity);
		return iroSalesEntity.save();
	}
	
	public boolean updateEntity(IroSalesDetailCom com){
		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
		iroSalesEntity.fromObject(com);
		calcArgItems(iroSalesEntity);
		return iroSalesEntity.update();
	}
	
	public boolean deleteEntity(IroSalesDetailCom com){
		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
		iroSalesEntity.fromObject(com);
		return iroSalesEntity.delete();
	}
	
	private void calcArgItems(IroSalesEntity iroSalesEntity){
		// 总价 ＝ 数量 ＊ 单价
		iroSalesEntity.setReceivable_amount_arg(iroSalesEntity.getQuantity()*iroSalesEntity.getPrice());
		// 已收款 ＝ 现金 ＋ 支票 ＋ 电汇 ＋ 承兑
		iroSalesEntity.setReceived_amount_arg(iroSalesEntity.getCash()+iroSalesEntity.getBill()+iroSalesEntity.getT_t()+iroSalesEntity.getAcceptance());
		// 未收款 ＝ 总价 － 已收款
		iroSalesEntity.setUncollected_amount_arg(iroSalesEntity.getReceivable_amount_arg()-iroSalesEntity.getReceived_amount_arg());
		// 应开发票 ＝ 总价 （交易类型未含税的情况下）
		boolean isTaxable = iroSalesEntity.getTransaction_type()!=null&&iroSalesEntity.getTransaction_type().equals(KEYWORD.TAXABLE);
		iroSalesEntity.setPayable_invoice_arg(isTaxable?iroSalesEntity.getReceivable_amount_arg():0);
		// 未开发票 ＝ 应开发票 － 已开发票
		iroSalesEntity.setUnpaid_invoice_arg(iroSalesEntity.getReceivable_amount_arg()-iroSalesEntity.getInvoice_amount());		
	}
	
}
