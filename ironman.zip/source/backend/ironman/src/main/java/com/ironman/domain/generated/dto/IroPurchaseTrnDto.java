package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class IroPurchaseTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2956493843742183461L;
	
	Long purchase_id;
	Long order_id;
	Long editor_role_id;
	Long vendor_id;
	Date purchase_date;
	String customer_name_rmk;
	String product_name;
	String spec;
	Double quantity;
	Double price;
	String transaction_type;
	Date payment_date;
	Double cash;
	Double bill;
	Double t_t;
	Double acceptance;
	String payer;
	String invoice_requirement;
	Date issue_invoice_date;
	Double invoice_amount;
	String seller;
	String invoice_no;
	String photocopy;
	Double receivable_invoice_arg;
	Double uncollected_invoice_arg;
	Double payable_amount_arg;
	Double paid_amount_arg;
	Double unpaid_amount_arg;
	

}
