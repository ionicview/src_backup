package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroVendorMstDto implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -1291987271596815797L;
	Long vendor_id;
	Long company_id;
	String compnay_name;
	String landline_phone;
	String address;
	Double estimated_payment;
	Double estimated_invoice;
	String finance_contact;
	String finance_phone;
	Timestamp create_datetime;
	Timestamp update_datetime;
	Integer del_flg;

}
