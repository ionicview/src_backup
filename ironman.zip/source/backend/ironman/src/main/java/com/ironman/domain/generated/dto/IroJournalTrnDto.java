package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroJournalTrnDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7933778056069285106L;
	
	Long journal_id;
	Long bank_id; 
	Long saler_id;
	String bank_account;
	String journal_usage;
	String 	journal_type;
	Double amount;
	String remark;
}
