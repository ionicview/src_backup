package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroPurchaseTrnDto;

public interface IroPurchaseRepositoryMapper {
	IroPurchaseTrnDto findByPK(IroPurchaseTrnDto iroPurchaseTrnDto);
}
