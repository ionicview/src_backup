package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroSalerCustomerRlsDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1764064992486581254L;
	Long saler_customer_rls_id;
	Long saler_id;
	Long customer_id;

}
