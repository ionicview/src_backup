package com.ironman.domain.constant;

public class PATH {
	
	public static String UPLOAD_PATH = "upload";
	
	public static String UPLOAD_ABSOLUTEPATH = "/Users/xuying/Documents/workspace/angularjs2/ironman/source/frontend/src/assets/img";

}
