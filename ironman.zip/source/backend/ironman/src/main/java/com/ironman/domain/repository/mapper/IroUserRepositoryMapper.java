package com.ironman.domain.repository.mapper;

import java.util.List;

import com.ironman.domain.generated.dto.IroUserMstDto;

public interface IroUserRepositoryMapper {

	IroUserMstDto findByPK(IroUserMstDto iroUserMstDto);
	IroUserMstDto findByAccountPwdCompany(IroUserMstDto iroUserMstDto);
	List<IroUserMstDto> findByCompany(IroUserMstDto iroUserMstDto);
}
