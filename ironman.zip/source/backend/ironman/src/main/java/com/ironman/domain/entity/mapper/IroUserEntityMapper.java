package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroUserMstDto;

public interface IroUserEntityMapper {
	int save(IroUserMstDto iroUserMstDto);
	int update(IroUserMstDto iroUserMstDto);
	int delete(IroUserMstDto iroUserMstDto);
}
