package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroSalesTrnDto;

public interface IroSalesRepositoryMapper {
	
	IroSalesTrnDto findByPK(IroSalesTrnDto iroSalesTrnDto);
	Long findLastSeq();
}
