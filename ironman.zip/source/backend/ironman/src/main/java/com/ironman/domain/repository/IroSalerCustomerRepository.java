package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroSalerCustomerEntity;
import com.ironman.domain.generated.dto.IroSalerCustomerRlsDto;
import com.ironman.domain.repository.mapper.IroSalerCustomerRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroSalerCustomerRepository {

	@Autowired
	IroSalerCustomerRepositoryMapper iroSalerCustomerRepositoryMapper;
	
	public IroSalerCustomerEntity findBySalerIdCustomerId(String saler_id, String customer_id){
		IroSalerCustomerRlsDto iroSalerCustomerRlsDto = BeanFactory.newBean(IroSalerCustomerRlsDto.class);
		iroSalerCustomerRlsDto.setSaler_id(Long.valueOf(saler_id));
		iroSalerCustomerRlsDto.setCustomer_id(Long.valueOf(customer_id));
		return findBySalerIdCustomerId(iroSalerCustomerRlsDto);
	}
	
	public IroSalerCustomerEntity findBySalerIdCustomerId(IroSalerCustomerRlsDto iroSalerCustomerRlsDto){
		IroSalerCustomerEntity entity = EntityFactory.newEntity(IroSalerCustomerEntity.class);
		IroSalerCustomerRlsDto result = iroSalerCustomerRepositoryMapper.findBySalerIdCustomerId(iroSalerCustomerRlsDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroSalerCustomerEntity findByPK(IroSalerCustomerRlsDto iroSalerCustomerRlsDto){
		IroSalerCustomerEntity entity = EntityFactory.newEntity(IroSalerCustomerEntity.class);
		IroSalerCustomerRlsDto result = iroSalerCustomerRepositoryMapper.findByPK(iroSalerCustomerRlsDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
}
