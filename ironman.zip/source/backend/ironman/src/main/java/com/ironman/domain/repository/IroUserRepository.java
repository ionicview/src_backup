package com.ironman.domain.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.generated.dto.IroUserMstDto;
import com.ironman.domain.repository.mapper.IroUserRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroUserRepository {

	@Autowired
	IroUserRepositoryMapper iroUserRepositoryMapper;
	

	public IroUserEntity findByPK(IroUserMstDto iroUserMstDto){
		IroUserEntity entity = EntityFactory.newEntity(IroUserEntity.class);
		IroUserMstDto result = iroUserRepositoryMapper.findByPK(iroUserMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroUserEntity findByAccountPwdCompany(IroUserMstDto iroUserMstDto){
		IroUserEntity entity = EntityFactory.newEntity(IroUserEntity.class);
		IroUserMstDto result = iroUserRepositoryMapper.findByAccountPwdCompany(iroUserMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroUserEntity findByAccountPwdCompany(String company_id, String account, String password){
		IroUserMstDto param = BeanFactory.newBean(IroUserMstDto.class);
		param.setCompany_id(Long.valueOf(company_id));
		param.setAccount(account);
		param.setPassword(password);
		return findByAccountPwdCompany(param);
	}
	
	public List<IroUserEntity> findByCompany(IroUserMstDto iroUserMstDto){
		
		List<IroUserMstDto> resultList = iroUserRepositoryMapper.findByCompany(iroUserMstDto);
		if (resultList == null || resultList.size() == 0) return null;
		List<IroUserEntity> entityList = new ArrayList<IroUserEntity>();
		for(IroUserMstDto result : resultList){
			IroUserEntity entity = EntityFactory.newEntity(IroUserEntity.class);
			entity.fromObject(result);
			entityList.add(entity);
		}
		return entityList;
	}
	
	public List<IroUserEntity> findByCompany(String company_id){
		IroUserMstDto param = BeanFactory.newBean(IroUserMstDto.class);
		param.setCompany_id(Long.valueOf(company_id));
		return findByCompany(param);
	}
	
}
