package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroOrderEntity;
import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.generated.dto.IroOrderTrnDto;
import com.ironman.domain.repository.mapper.IroOrderRepositoryMapper;
import com.ironman.domain.service.result.IroSalesDetailCom;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroOrderRepository {
	@Autowired
	IroOrderRepositoryMapper iroOrderRepositoryMapper;
	
	public IroOrderEntity findByPK(IroOrderTrnDto iroOrderTrnDto){
		IroOrderEntity entity = EntityFactory.newEntity(IroOrderEntity.class);
		IroOrderTrnDto result = iroOrderRepositoryMapper.findByPK(iroOrderTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}

// 不用的函数
//	public IroOrderEntity findLatestOne(){
//		IroOrderEntity entity = EntityFactory.newEntity(IroOrderEntity.class);
//		IroOrderTrnDto result = iroOrderRepositoryMapper.findLatestOne();
//		if (result == null) return null;
//		entity.fromObject(result);
//		return entity;
//	}
	
	public Long findLastSeq(){
		return iroOrderRepositoryMapper.findLastSeq();
	}
	
	public boolean newEntity(IroOrderTrnDto iroOrderTrnDto){
		IroOrderEntity iroOrderEntity = EntityFactory.newEntity(IroOrderEntity.class);
		iroOrderEntity.fromObject(iroOrderTrnDto);
		return iroOrderEntity.save();
	}
	
	public boolean newEntity(Long order_id, String order_name, long saler_customer_rls_id){
		IroOrderTrnDto iroOrderTrnDto = BeanFactory.newBean(IroOrderTrnDto.class);
		iroOrderTrnDto.setOrder_id(order_id);
		iroOrderTrnDto.setOrder_name(order_name);
		iroOrderTrnDto.setSaler_customer_rls_id(saler_customer_rls_id);
		return newEntity(iroOrderTrnDto);
	}
	
	public boolean updateEntity(IroSalesDetailCom iroSalesDetailCom){
		IroOrderEntity iroOrderEntity = EntityFactory.newEntity(IroOrderEntity.class);
		iroOrderEntity.fromObject(iroSalesDetailCom);
		return iroOrderEntity.update();
	}
	
	public boolean deleteEntity(IroSalesDetailCom iroSalesDetailCom){
		IroOrderEntity iroOrderEntity = EntityFactory.newEntity(IroOrderEntity.class);
		iroOrderEntity.fromObject(iroSalesDetailCom);
		return iroOrderEntity.delete();
	}
}
