package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;
import com.ironman.domain.repository.mapper.IroCompanyRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroCompanyRepository {

	@Autowired
	IroCompanyRepositoryMapper iroCompanyRepositoryMapper;
	
	public IroCompanyEntity findByPK(IroCompanyMstDto iroCompanyMstDto){
		IroCompanyEntity entity = EntityFactory.newEntity(IroCompanyEntity.class);
		IroCompanyMstDto result = iroCompanyRepositoryMapper.findByPK(iroCompanyMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	 
	public IroCompanyEntity findByDomainName(IroCompanyMstDto iroCompanyMstDto){
		IroCompanyEntity entity = EntityFactory.newEntity(IroCompanyEntity.class);
		IroCompanyMstDto result = iroCompanyRepositoryMapper.findByDomainName(iroCompanyMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	
	public IroCompanyEntity findByDomainName(String domainName){
		IroCompanyMstDto iroCompanyMstDto = BeanFactory.newBean(IroCompanyMstDto.class);
		iroCompanyMstDto.setDomain_name(domainName);
		return findByDomainName(iroCompanyMstDto);
	}
}
