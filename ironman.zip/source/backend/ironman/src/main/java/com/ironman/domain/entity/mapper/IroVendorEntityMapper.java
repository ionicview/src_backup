package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroVendorMstDto;

public interface IroVendorEntityMapper {
	int save(IroVendorMstDto iroVendorMstDto);
	int update(IroVendorMstDto iroVendorMstDto);
//	int delete(IroVendorMstDto iroVendorMstDto);
}
