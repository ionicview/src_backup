package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroRoleEntity;
import com.ironman.domain.generated.dto.IroRoleMstDto;
import com.ironman.domain.repository.mapper.IroRoleRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroRoleRepository {
	@Autowired
	IroRoleRepositoryMapper iroRoleRepositoryMapper;
	
	public IroRoleEntity findByPK(IroRoleMstDto iroRoleMstDto){
		IroRoleEntity entity = EntityFactory.newEntity(IroRoleEntity.class);
		IroRoleMstDto result = iroRoleRepositoryMapper.findByPK(iroRoleMstDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroRoleEntity findByRoleId(long role_id){
		IroRoleMstDto param = BeanFactory.newBean(IroRoleMstDto.class);
		param.setRole_id(role_id);
		return findByPK(param);
	}
}
