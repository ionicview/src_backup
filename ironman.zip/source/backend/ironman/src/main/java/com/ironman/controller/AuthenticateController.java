package com.ironman.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.google.gson.JsonObject;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;
import com.ironman.domain.service.IroAuthenticateService;
/**
 * 验证相关的控制类
 * 
 * @author Wang
 * 
 */
@CrossOrigin
@RestController
@RequestMapping(KEYWORD.AUTHENTICATE)
@SessionAttributes({ KEYWORD.MENUFORM })
public class AuthenticateController {
	
	@Autowired
	private IroAuthenticateService iroAuthenticateService;

	private static Logger log = Logger.getLogger(AuthenticateController.class);

	/**
	 * 根据公司域名获取公司系统名字
	 * 
	 * @param domain_name 域名
	 * @param resp 
	 *     
	 * @return 公司系统名字
	 */
	@RequestMapping(value = KEYWORD.GETSYSTEMNAME, method = RequestMethod.GET)
	@ResponseBody
	public IroCompanyMstDto getSystemName(@RequestParam(KEYWORD.DOMAIN_NAME) String domain_name,
			HttpServletResponse resp) {
		
		if (null == domain_name || domain_name.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		IroCompanyEntity iroCompanyEntity = iroAuthenticateService.findByDomainName(domain_name);
		
		if( null == iroCompanyEntity){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}

		resp.setStatus(HttpServletResponse.SC_OK);
		return (IroCompanyMstDto)iroCompanyEntity;
	}
	
	/**
	 * 根据用户登录信息进行验证，验证成功后返回该用户的JWT (JSON Web Token) 
	 * 
	 * @param company_id 公司ID
	 * @param account 用户登录行号
	 * @param password 用户登录密码
	 * @param resp 
	 *     
	 * @return 用户的JWT (JSON Web Token) 
	 */
	@RequestMapping(value = KEYWORD.VERIFYUSER, method = RequestMethod.GET)
	@ResponseBody
	public String verifyUser(@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			                 @RequestParam(KEYWORD.ACCOUNT) String account,
			                 @RequestParam(KEYWORD.PASSWORD) String password,
			                 HttpServletResponse resp) throws IOException {
		
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == account || account.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == password || password.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		
		JsonObject json = iroAuthenticateService.verifyUser(company_id, account, password);
		if (json == null) resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
		return json.toString();

	}
	
}