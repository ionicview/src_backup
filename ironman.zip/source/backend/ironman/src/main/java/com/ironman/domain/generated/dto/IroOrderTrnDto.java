package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroOrderTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5826897269314444789L;
	Long order_id;
	String order_name;
	Long saler_customer_rls_id;

}
