package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroPurchaseTrnDto;

public interface IroPurchaseEntityMapper {
	int save(IroPurchaseTrnDto iroPurchaseTrnDto);
	int update(IroPurchaseTrnDto iroPurchaseTrnDto);
	int delete(IroPurchaseTrnDto iroPurchaseTrnDto);
}
