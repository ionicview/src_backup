package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroUserStatusTrnDto;

public interface IroUserStatusEntityMapper {
	int save(IroUserStatusTrnDto iroUserStatusTrnDto);
	int update(IroUserStatusTrnDto iroUserStatusTrnDto);
	int delete(IroUserStatusTrnDto iroUserStatusTrnDto);
}
