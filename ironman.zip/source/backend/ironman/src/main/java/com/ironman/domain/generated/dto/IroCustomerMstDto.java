package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroCustomerMstDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7597505246688046316L;
	
	Long customer_id;
	String company_name;
	String landline_phone;
	String address;
	String finance_contact;
	String finance_phone;
	Timestamp create_datetime;
	Timestamp update_datetime;
	Integer del_flg;
}
