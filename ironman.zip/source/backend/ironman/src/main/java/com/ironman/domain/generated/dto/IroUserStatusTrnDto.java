package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroUserStatusTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5895783661416836295L;
	
	Long user_id;
	String secret_key;
	Timestamp update_datetime;

}
