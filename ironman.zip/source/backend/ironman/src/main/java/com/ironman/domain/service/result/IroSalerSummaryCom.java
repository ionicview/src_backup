package com.ironman.domain.service.result;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroSalerSummaryCom  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5591216374443809646L;
	Long company_id;
	String saler_id;
	String saler;
	String mobile_phone;
	Double payable_invoice;
	Double paid_invoice;
	Double unpaid_invoice;
	Double receivable_amount;
	Double received_amount;
	Double uncollected_amount;
}
