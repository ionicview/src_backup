package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroVendorMstDto;

public interface IroVendorRepositoryMapper {

	IroVendorMstDto findByPK(IroVendorMstDto iroVendorMstDto);
}
