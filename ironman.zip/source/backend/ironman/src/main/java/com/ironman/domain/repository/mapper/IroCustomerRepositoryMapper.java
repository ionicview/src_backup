package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroCustomerMstDto;

public interface IroCustomerRepositoryMapper {
	
	IroCustomerMstDto findByPK(IroCustomerMstDto iroCustomerMstDto);

}
