package com.ironman.domain.service.result;

import java.io.Serializable;

public class IroCustomerSummaryCom implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1425449583557358474L;
	Long customer_id;
	String customer;
	String landline_phone;
	Double payable_invoice;
	Double paid_invoice;
	Double unpaid_invoice;
	Double receivable_amount;
	Double received_amount;
	Double uncollected_amount;
}
