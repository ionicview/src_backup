package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroSalerCustomerRlsDto;

public interface IroSalerCustomerEntityMapper {
	int save(IroSalerCustomerRlsDto iroSalerCustomerRlsDto);
	int update(IroSalerCustomerRlsDto iroSalerCustomerRlsDto);
	int delete(IroSalerCustomerRlsDto iroSalerCustomerRlsDto);
}
