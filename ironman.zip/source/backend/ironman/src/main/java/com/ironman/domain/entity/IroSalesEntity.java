package com.ironman.domain.entity;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.ironman.domain.entity.mapper.IroSalesEntityMapper;
import com.ironman.domain.generated.dto.IroSalesTrnDto;
import com.ironman.domain.service.result.IroSalesDetailCom;
import com.rainbow.fw.core.notation.Entity;


@Entity
@SuppressWarnings("serial")
public class IroSalesEntity extends IroSalesTrnDto {
	@Autowired
	private IroSalesEntityMapper mapper;

	public void fromObject(Object from) {
		BeanUtils.copyProperties(from, this);
	}

	public void toObject(Object to) {
		BeanUtils.copyProperties(this, to);
	}

	/**
	 * 插入记录
	 * 
	 * @return 插入结果
	 */
	public boolean save() {
		return 0 < mapper.save(this) ? true : false;
	}

	/**
	 * 更新
	 * 
	 * @return 更新结果
	 */
	public boolean update() {
		return 0 < mapper.update(this) ? true : false;
	}

	/**
	 * 删除
	 * 
	 * @return 删除结果
	 */
	public boolean delete() {
		return 0 < mapper.delete(this) ? true : false;
	}
}
