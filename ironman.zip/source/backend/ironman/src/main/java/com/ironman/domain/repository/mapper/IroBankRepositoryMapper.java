package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroBankMstDto;

public interface IroBankRepositoryMapper {
	IroBankMstDto findByPK(IroBankMstDto iroBankMstDto);
}
