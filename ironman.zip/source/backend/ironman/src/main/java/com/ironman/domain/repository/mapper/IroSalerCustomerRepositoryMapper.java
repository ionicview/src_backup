package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroSalerCustomerRlsDto;

public interface IroSalerCustomerRepositoryMapper {
	IroSalerCustomerRlsDto findByPK(IroSalerCustomerRlsDto iroSalerCustomerRlsDto);
	IroSalerCustomerRlsDto findBySalerIdCustomerId(IroSalerCustomerRlsDto iroSalerCustomerRlsDto);
}
