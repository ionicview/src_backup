package com.ironman.domain.constant;

public class KEYWORD {
	final public static String JWT = "jwt";
	final public static String PATH = "path";
	final public static String TITLE = "title";
	final public static String ICON = "icon";
	final public static String SELECTED = "selected";
	final public static String EXPANDED = "expanded";
	final public static String ORDER = "order";
	final public static String MENU = "menu";
	final public static String DATA = "data";
	final public static String CHILDREN = "children";
	final public static String TYPE = "type";
	final public static String ALGORITHM = "algorithm";
	final public static String SHA256 = "sha256";
	final public static String ROLE_ID = "role_id";
	final public static String EDITOR_ROLE_ID = "editor_role_id";
	final public static String REFERENCE_ROLE_ID = "reference_role_id";
	final public static String SALER_ROLE_ID = "saler_role_id";
	

	
	
	final public static String TAXABLE = "含税";
	final public static String NON_TAXABLE = "不含税";

	final public static String SMARTABLE_SETTING_ITEM_ID="smartable_setting_item_id";
	


	final public static String LOGOUT = "general.menu.logout";
	final public static String URL = "url";

	
	final public static String AUTHENTICATE = "/authenticate";
	final public static String VERIFYUSER = "verifyuser";
	final public static String MENUFORM = "menuForm";
	final public static String GETSYSTEMNAME = "getsystemname";
	final public static String GETMENU = "getmenu";
	
	final public static String SALES = "/sales";
	final public static String MANAGEMENT = "/management";
	
	final public static String SALER_SUMMARY_SETTING = "saler_summary_setting";
	final public static String SALER_SUMMARY_DATA = "saler_summary_data";
	final public static String SALER_CUSTOMER_SUMMARY_SETTING = "saler_customer_summary_setting";
	final public static String SALER_CUSTOMER_SUMMARY_DATA = "saler_customer_summary_data";
	
	final public static String SALES_DETAIL_SETTING = "sales_detail_setting";
	final public static String SALES_DETAIL_DATA = "sales_detail_data";
	
	final public static String MANAGEMENT_USER_DATA = "management_user_data";

	
	final public static String DOMAIN_NAME = "domain_name";
	final public static String COMPANY_ID = "company_id";
	final public static String USER_ID = "user_id";
	final public static String ACCOUNT = "account";
	final public static String PASSWORD = "password";
	final public static String SALER = "saler";
	final public static String SALER_ID = "saler_id";
	final public static String CUSTOMER = "customer";
	final public static String CUSTOMER_ID = "customer_id";
	final public static String COLUMNS = "columns";
	
	final public static String PHONE = "phone";
	final public static String PAYABLE_INVOICE = "payable_invoice";
	final public static String PAID_INVOICE = "paid_invoice";
	final public static String UNPAID_INVOICE = "unpaid_invoice";
	final public static String RECEIVABLE_AMOUNT = "receivable_amount";
	final public static String RECEIED_AMOUNT = "received_amount";
	final public static String UNCOLLECTED_AMOUNT = "uncollected_amount";
	
	final public static String SALES_ID = "sales_id";
	final public static String PRODUCT_ID = "product_id";
	final public static String PRODUCT_NAME = "product_name";
	final public static String SPEC = "spec";
	final public static String ORDER_NO = "order_no";
	final public static String SALE_DATE = "sale_date";
	final public static String TRANSACTIONTYPE = "transactionType";
	final public static String QUANTITY = "quantity";
	final public static String PRICE = "price";
	final public static String PAY_DATE = "pay_date";
	final public static String CASH = "cash";
	final public static String BILL = "bill";
	final public static String T_T = "t_t";
	final public static String ACCEPTANCE = "acceptance ";
	final public static String AMOUNT = "amount";
	final public static String PAYER = "payer";
	
	final public static String ISSUE_INVOICE_DATE = "issue_invoice_date";
	final public static String INVOICE_AMOUNT = "invoice_amount";
	final public static String BUYER = "buyer";
	final public static String INVOICE_NO = "invoice_no";
	final public static String PHOTOCOPY = "photocopy";
	final public static String PHOTOCOPY_FILE = "file";
	
	final public static String RECORD = "record";

}


