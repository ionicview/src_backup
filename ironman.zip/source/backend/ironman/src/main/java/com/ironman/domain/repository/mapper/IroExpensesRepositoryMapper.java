package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroExpensesTrnDto;

public interface IroExpensesRepositoryMapper {
	IroExpensesTrnDto findByPK(IroExpensesTrnDto iroExpensesTrnDto);
}
