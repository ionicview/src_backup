package com.ironman.domain.constant;

public class ID {
	final public static int MANAGER_ROLE_ID=1;
	final public static int ACCOUNTANT_ROLE_ID=2;
	final public static int PURCHASE_MANAGER_ROLE_ID=3;
	final public static int SALES_MANAGER_ROLE_ID=4;
	final public static int SALER_ROLE_ID=5;
}
