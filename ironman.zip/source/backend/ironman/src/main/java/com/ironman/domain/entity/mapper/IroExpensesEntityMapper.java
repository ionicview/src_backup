package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroExpensesTrnDto;

public interface IroExpensesEntityMapper {
	int save(IroExpensesTrnDto iroExpensesTrnDto);
	int update(IroExpensesTrnDto iroExpensesTrnDto);
	int delete(IroExpensesTrnDto iroExpensesTrnDto);
}
