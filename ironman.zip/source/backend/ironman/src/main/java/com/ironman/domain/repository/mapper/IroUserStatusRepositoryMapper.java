package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroUserStatusTrnDto;

public interface IroUserStatusRepositoryMapper {

	IroUserStatusTrnDto findByPK(IroUserStatusTrnDto iroUserStatusTrnDto);
}
