package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroRoleMstDto;

public interface IroRoleRepositoryMapper {
	IroRoleMstDto findByPK(IroRoleMstDto iroRoleMstDto);
}
