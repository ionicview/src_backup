package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroCompanyMstDto;

public interface IroCompanyRepositoryMapper {
	IroCompanyMstDto findByPK(IroCompanyMstDto iroCompanyMstDto);
	IroCompanyMstDto findByDomainName(IroCompanyMstDto iroCompanyMstDto);
	
}
