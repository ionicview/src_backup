package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroBankMstDto;

public interface IroBankEntityMapper {
	int save(IroBankMstDto iroBankMstDto);
	int update(IroBankMstDto iroBankMstDto);
	int delete(IroBankMstDto iroBankMstDto);
}
