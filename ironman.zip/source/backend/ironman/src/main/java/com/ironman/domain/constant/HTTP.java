package com.ironman.domain.constant;

public class HTTP {
	final public static String AUTHORIZE_FAILED = "登录失败";
	final public static String INVALID_JWT = "无效的jwt";
	final public static String NO_CONTENT = "请求中却少内容，比如空参数";

}
