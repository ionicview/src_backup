package com.ironman.domain.entity;

import java.sql.Timestamp;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.ironman.domain.entity.mapper.IroUserStatusEntityMapper;
import com.ironman.domain.generated.dto.IroUserStatusTrnDto;
import com.rainbow.fw.constant.CONSTANT;
import com.rainbow.fw.core.notation.Entity;
import com.rainbow.fw.core.util.DateTimeUtil;

@Entity
@SuppressWarnings("serial")
public class IroUserStatusEntity extends IroUserStatusTrnDto {
	@Autowired
	private IroUserStatusEntityMapper mapper;

	public void fromObject(Object from) {
		BeanUtils.copyProperties(from, this);
	}

	public void toObject(Object to) {
		BeanUtils.copyProperties(this, to);
	}

	/**
	 * 插入记录
	 * 
	 * @return 插入结果
	 */
	public boolean save() {
		return 0 < mapper.save(this) ? true : false;
	}

	/**
	 * 更新
	 * 
	 * @return 更新结果
	 */
	public boolean update() {
		return 0 < mapper.update(this) ? true : false;
	}

	/**
	 * 删除
	 * 
	 * @return 删除结果
	 */
	public boolean delete() {
		return 0 < mapper.delete(this) ? true : false;
	}
	
	
	public boolean update(String secretKey){
		setSecret_key(secretKey);
		setUpdate_datetime(new Timestamp(System.currentTimeMillis()));
		return update();
	}
		
	public boolean isTimeOut(){
		return DateTimeUtil.timestampCompare(getUpdate_datetime(), CONSTANT.TIMEOUTSPAN);
	}
	
	public boolean updateDateTime(boolean isTimeOut){
		if (isTimeOut){	
			delete();
			return true;
		}
		else{
			update();
			return false; 
		}
	}

}
