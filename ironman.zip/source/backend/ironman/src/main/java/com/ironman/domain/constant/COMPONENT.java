package com.ironman.domain.constant;

public class COMPONENT {
	final public static int SALER_SUMMARY_TABLE_ID=30101;
	final public static int SALER_CUSTOMER_SUMMARY_TABLE_ID=30201;
	final public static int SALES_DETAIL_TABLE_ID=30301;
}
