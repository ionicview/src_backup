package com.ironman.domain.service.mapper;

import java.util.HashMap;
import java.util.List;

import com.ironman.domain.service.result.IroCustomerSummaryCom;
import com.ironman.domain.service.result.IroSalerSummaryCom;
import com.ironman.domain.service.result.IroSalesDetailCom;

public interface IroSalesServiceMapper {
	List<IroSalerSummaryCom> findSalerSalesSummary(HashMap<String,Object> param);
	List<IroCustomerSummaryCom> findCustomerSalesSummary(HashMap<String,Object> param);
	List<IroSalesDetailCom> findSalesDetail(HashMap<String,Object> param);
}
