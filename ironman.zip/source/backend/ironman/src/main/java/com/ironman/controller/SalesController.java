package com.ironman.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;
import com.ironman.domain.constant.HTTP;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.constant.URL;
import com.ironman.domain.service.IroAuthenticateService;
import com.ironman.domain.service.IroSalesService;
import com.rainbow.fw.core.util.ConverterUtil;

/**
 * 销售相关的控制类
 * 
 * @author Wang
 * 
 */
@CrossOrigin
@RestController
@RequestMapping(KEYWORD.SALES)
public class SalesController {
	
	@Autowired
	private IroSalesService iroSalesService;
	
	@Autowired
	private IroAuthenticateService iroAuthenticateService;
	
	
	/**
	 * 取得销售的以业务员为单位的集计页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param resp 
	 *     
	 * @return 数据信息
	 */
	@RequestMapping(value = URL.GET_SALER_SUMMARY_DATA, method = RequestMethod.GET)
	@ResponseBody
	public Map getSalerSummaryData(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.REFERENCE_ROLE_ID) String reference_role_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == reference_role_id || reference_role_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return null;
		}
		
		resp.setStatus(HttpServletResponse.SC_OK);
		
		return iroSalesService.getSalerSummaryData(company_id, reference_role_id);
	}
	
	/**
	 * 取得销售的以客户为单位的集计页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param resp 
	 *     
	 * @return 数据信息
	 */
	@RequestMapping(value = URL.GET_SALER_CUSTOMER_SUMMARY_DATA, method = RequestMethod.GET)
	@ResponseBody
	public Map getSalerCustomerSummaryData(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.SALER_ID) String saler_id,
			@RequestParam(KEYWORD.REFERENCE_ROLE_ID) String reference_role_id,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == saler_id || saler_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return null;
		}
		
		resp.setStatus(HttpServletResponse.SC_OK);
		
		return iroSalesService.getCustomerSummaryData(saler_id, reference_role_id);
	}
	
	
	/**
	 * 取得销售详细页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param resp 
	 *     
	 * @return 数据信息
	 */
	@RequestMapping(value = URL.GET_SALES_DETAIL_DATA, method = RequestMethod.GET)
	@ResponseBody
	public Map getSalesDetailData(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.CUSTOMER_ID) String customer_id,
			@RequestParam(KEYWORD.REFERENCE_ROLE_ID) String reference_role_id,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == reference_role_id || reference_role_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return null;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return null;
		}
		
		resp.setStatus(HttpServletResponse.SC_OK);
		
		return iroSalesService.getSalesDetailData(customer_id, reference_role_id);
	}
	
	/**
	 * 把销售详细信息插入销售表
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param record 销售详细信息
	 * @param resp 
	 * 
	 * @return 插入成功与否
	 */
	@RequestMapping(value = URL.NEW_SALES, method = RequestMethod.GET)
	@ResponseBody
	public boolean newSalesDetail(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.RECORD) String record,
			@RequestParam(KEYWORD.SALER_ID) String saler_id,
			@RequestParam(KEYWORD.CUSTOMER_ID) String customer_id,
			@RequestParam(KEYWORD.ROLE_ID) String role_id,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == saler_id || saler_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == customer_id || customer_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == role_id || role_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		JsonObject jsonRecord = ConverterUtil.toJsonObject(record);
		if (null == jsonRecord ){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return false;
		}
		
		boolean res = false;
		try {
			res = iroSalesService.newSalesDetail(saler_id, customer_id, role_id, jsonRecord);
		} catch (Exception e) {
		}
		if (res == true) 
			resp.setStatus(HttpServletResponse.SC_OK);
		else 
			resp.setStatus(HttpServletResponse.SC_CREATED);
		return  res;
	}
	
	/**
	 * 把指定的销售详细信息进行修改销售表
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param iroSalesJsonStr 销售详细信息
	 * @param resp 
	 * 
	 * @return 修改成功与否
	 */
	@RequestMapping(value = URL.UPDATE_SALES, method = RequestMethod.GET)
	@ResponseBody
	public boolean updateSalesDetail(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.RECORD) String record,
			@RequestParam(KEYWORD.SALER_ID) String saler_id,
			@RequestParam(KEYWORD.CUSTOMER_ID) String customer_id,
			@RequestParam(KEYWORD.ROLE_ID) String role_id,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == saler_id || saler_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == customer_id || customer_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == role_id || role_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		JsonObject jsonRecord = ConverterUtil.toJsonObject(record);
		if (null == jsonRecord ){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return false;
		}
		
		boolean res = false;
		try {
			res = iroSalesService.updateSalesDetail(jsonRecord);
		} catch (Exception e) {
		}
		if (res == true) 
			resp.setStatus(HttpServletResponse.SC_OK);
		else 
			resp.setStatus(HttpServletResponse.SC_CREATED);
		return  res;
	}
	
	/**
	 * 把指定的销售详细信息从销售表中删除
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param jwt 用户JWT
	 * @param sales_id 
	 * @param product_id 
	 * @param resp 
	 * 
	 * @return 删除成功与否
	 */
	@RequestMapping(value = URL.DELETE_SALES, method = RequestMethod.GET)
	@ResponseBody
	public boolean deleteSalesDetail(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.RECORD) String record,
			@RequestParam(KEYWORD.SALER_ID) String saler_id,
			@RequestParam(KEYWORD.CUSTOMER_ID) String customer_id,
			@RequestParam(KEYWORD.ROLE_ID) String role_id,
			HttpServletResponse resp) throws IOException {
		
		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == saler_id || saler_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == customer_id || customer_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == role_id || role_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		JsonObject jsonRecord = ConverterUtil.toJsonObject(record);
		if (null == jsonRecord ){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return false;
		}
		
		boolean res = false;
		try {
			res = iroSalesService.deleteSalesDetail(jsonRecord);
		} catch (Exception e) {
		}
		if (res == true) 
			resp.setStatus(HttpServletResponse.SC_OK);
		else 
			resp.setStatus(HttpServletResponse.SC_CREATED);
		return  res;
	}
	
	@RequestMapping(value = URL.UPLOAD_PHOTOCOPY, method = RequestMethod.POST)
	@ResponseBody
	public boolean uploadPhotocopy(@RequestParam(KEYWORD.USER_ID) String user_id,
			@RequestParam(KEYWORD.COMPANY_ID) String company_id,
			@RequestParam(KEYWORD.JWT) String jwt,
			@RequestParam(KEYWORD.SALES_ID) String sales_id,
			@RequestParam(KEYWORD.PHOTOCOPY_FILE) MultipartFile multipartFile,
			HttpServletResponse resp) throws IOException {

		if (null == user_id || user_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == company_id || company_id.isEmpty()){
			resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
			return false;
		}
		if (null == jwt || jwt.isEmpty() || !iroAuthenticateService.isValidJwt(company_id, user_id, jwt)){
			resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, HTTP.AUTHORIZE_FAILED);
			return false;
		}
		
		boolean res = false;
		try {
			res = iroSalesService.updatePhotocopy(Long.parseLong(sales_id), multipartFile);
		} catch (Exception e) {
		}
		if (res == true) 
			resp.setStatus(HttpServletResponse.SC_OK);
		else 
			resp.setStatus(HttpServletResponse.SC_CREATED);
		return  res;
	}

}
