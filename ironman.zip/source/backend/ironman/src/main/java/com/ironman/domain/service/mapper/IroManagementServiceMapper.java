package com.ironman.domain.service.mapper;

import java.util.List;

import com.ironman.domain.service.result.IroUserManagementCom;

public interface IroManagementServiceMapper {
	
	List<IroUserManagementCom> findByCompany(Long company_id);

}
