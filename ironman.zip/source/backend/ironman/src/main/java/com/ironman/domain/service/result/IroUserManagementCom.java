package com.ironman.domain.service.result;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroUserManagementCom implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7800712288922820994L;
	Long user_id;
	Long company_id;
	Long role_id;
	String role_name;
	String account;
	String password;
	String name;
	String sex;
	String landline_phone;
	String mobile_phone;
	String address;
	String email;
	Timestamp last_login_datetime;
	Long login_count;
	Timestamp create_datetime;
	Timestamp update_datetime;
	Integer del_flg;

}
