package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroCustomerMstDto;

public interface IroCustomerEntityMapper {
	int save(IroCustomerMstDto iroCustomerMstDto);
	int update(IroCustomerMstDto iroCustomerMstDto);
//	int delete(IroCustomerMstDto iroCustomerMstDto);
}
