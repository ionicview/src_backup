package com.ironman.domain.service.result;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class IroSalesDetailCom implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5758100877894991290L;

	Long order_id;
	String order_name;
	Long saler_customer_rls_id;
	Long sales_id;
	Long editor_role_id;
	Date sales_date;
	String vendor_name_rmk;
	String transaction_type;
	String product_name;
	String spec;
	Double quantity;
	Double price;
	Double receivable_amount_arg;
	Double payable_invoice_arg;
	Date payment_date;
	Double cash;
	Double bill;
	Double t_t;
	Double acceptance;
	Double received_amount_arg;
	String payer;
	Double uncollected_amount_arg;
	Date issue_invoice_date;
	Double invoice_amount;
	String buyer;
	String invoice_no;
	String photocopy;
	Double unpaid_invoice_arg;
}
