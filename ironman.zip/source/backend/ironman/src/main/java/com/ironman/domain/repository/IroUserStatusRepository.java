package com.ironman.domain.repository;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroUserStatusEntity;
import com.ironman.domain.generated.dto.IroUserStatusTrnDto;
import com.ironman.domain.repository.mapper.IroUserStatusRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroUserStatusRepository {
	@Autowired
	IroUserStatusRepositoryMapper iroUserStatusRepositoryMapper;
	

	public IroUserStatusEntity findByPK(IroUserStatusTrnDto iroUserStatusTrnDto){
		IroUserStatusEntity entity = EntityFactory.newEntity(IroUserStatusEntity.class);
		IroUserStatusTrnDto result = iroUserStatusRepositoryMapper.findByPK(iroUserStatusTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
	
	public IroUserStatusEntity findByPK(String user_id){
		IroUserStatusTrnDto param = BeanFactory.newBean(IroUserStatusTrnDto.class);
		param.setUser_id(Long.valueOf(user_id));
		return findByPK(param);
	}
	
	public boolean newEntity(String user_id, String secretKey){
		IroUserStatusEntity userStatusEntity = EntityFactory.newEntity(IroUserStatusEntity.class);
		userStatusEntity.setUser_id(Long.valueOf(user_id));
		userStatusEntity.setSecret_key(secretKey);
		userStatusEntity.setUpdate_datetime(new Timestamp(System.currentTimeMillis()));
		return userStatusEntity.save();
	}
}
