package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroBankMstDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4468258924556808719L;
	
	Long bank_id;
	String bank_name ;
	Timestamp create_datetime;
	Timestamp update_datetime;
	Integer del_flg; 
	

}
