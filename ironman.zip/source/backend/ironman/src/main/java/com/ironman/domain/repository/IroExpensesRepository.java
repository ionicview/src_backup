package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroExpensesEntity;
import com.ironman.domain.generated.dto.IroExpensesTrnDto;
import com.ironman.domain.repository.mapper.IroExpensesRepositoryMapper;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroExpensesRepository {
	
	@Autowired
	IroExpensesRepositoryMapper iroExpensesRepositoryMapper;
	
	public IroExpensesEntity findByPK(IroExpensesTrnDto iroExpensesTrnDto){
		IroExpensesEntity entity = EntityFactory.newEntity(IroExpensesEntity.class);
		IroExpensesTrnDto result = iroExpensesRepositoryMapper.findByPK(iroExpensesTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
}
