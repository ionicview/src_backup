package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroOrderTrnDto;

public interface IroOrderRepositoryMapper {
	IroOrderTrnDto findByPK(IroOrderTrnDto iroOrderTrnDto);
	IroOrderTrnDto findLatestOne();
	Long findLastSeq();
}
