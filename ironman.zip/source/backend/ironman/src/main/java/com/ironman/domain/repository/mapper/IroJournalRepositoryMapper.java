package com.ironman.domain.repository.mapper;

import com.ironman.domain.generated.dto.IroJournalTrnDto;

public interface IroJournalRepositoryMapper {
	IroJournalTrnDto findByPK(IroJournalTrnDto iroJournalTrnDto);

}
