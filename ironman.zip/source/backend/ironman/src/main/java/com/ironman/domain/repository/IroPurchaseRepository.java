package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroPurchaseEntity;
import com.ironman.domain.generated.dto.IroPurchaseTrnDto;
import com.ironman.domain.repository.mapper.IroPurchaseRepositoryMapper;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroPurchaseRepository {

	
	@Autowired
	IroPurchaseRepositoryMapper iroPurchaseRepositoryMapper;
	
	public IroPurchaseEntity findByPK(IroPurchaseTrnDto iroPurchaseTrnDto){
		IroPurchaseEntity entity = EntityFactory.newEntity(IroPurchaseEntity.class);
		IroPurchaseTrnDto result = iroPurchaseRepositoryMapper.findByPK(iroPurchaseTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
}
