package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroExpensesTrnDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8233706304223267582L;
	Long expenses_id;
	Long order_id;
	Double expenses_amount; 
	String expenses_usage;
	String remarks;
}
