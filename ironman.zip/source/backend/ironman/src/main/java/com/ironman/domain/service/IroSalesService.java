package com.ironman.domain.service;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ironman.domain.constant.ID;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.constant.SPECIALCHARACTER;
import com.ironman.domain.entity.IroSalerCustomerEntity;
import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.generated.dto.IroSalesTrnDto;
import com.ironman.domain.repository.IroOrderRepository;
import com.ironman.domain.repository.IroSalerCustomerRepository;
import com.ironman.domain.repository.IroSalesRepository;
import com.ironman.domain.service.mapper.IroSalesServiceMapper;
import com.ironman.domain.service.result.IroCustomerSummaryCom;
import com.ironman.domain.service.result.IroSalerSummaryCom;
import com.ironman.domain.service.result.IroSalesDetailCom;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;
import com.rainbow.fw.core.util.ConverterUtil;

/**
 * 销售相关的服务类
 * 
 * @author Wang
 * 
 */
@Service
public class IroSalesService {
	
	@Autowired
	IroSalesRepository iroSalesRepository;
	
	@Autowired
	IroSalesServiceMapper iroSalesServiceMapper;
	
	@Autowired
	IroSalerCustomerRepository iroSalerCustomerRlsRepository;
	
	@Autowired
	IroOrderRepository iroOrderRepository;
	
	@Autowired
	IroStorageService iroStorageService;
	
	
	/**
	 * 取得销售的以业务员为单位的集计页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 数据信息
	 */
	public Map getSalerSummaryData(String company_id, String reference_role_id){
	    List<IroSalerSummaryCom> iroSalerSummaryComs = findSalerSalesSummary(company_id, reference_role_id);
	    HashMap<String, Object> salerSummaryDataMap = new HashMap<String,Object>();
	    salerSummaryDataMap.put(KEYWORD.SALER_SUMMARY_DATA, iroSalerSummaryComs);
	    return salerSummaryDataMap;
	}
	
	/**
	 * 取得销售的详细页面数据信息
	 * 
	 * @param company_id 公司ID
	 * @param saler_id 业务员ID
	 *     
	 * @return 数据信息
	 */
	public Map getCustomerSummaryData(String saler_id, String reference_role_id){
	    List<IroCustomerSummaryCom> records = findCustomerSalesSummary(saler_id, reference_role_id);
	    HashMap<String, Object> salerSummaryDataMap = new HashMap<String,Object>();
	    salerSummaryDataMap.put(KEYWORD.SALER_CUSTOMER_SUMMARY_DATA, records);
	    return salerSummaryDataMap;
	}
	
	/**
	 * 取得销售的详细页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 数据信息
	 */
	public Map getSalesDetailData(String customer_id, String reference_role_id){
	    List<IroSalesDetailCom> records = findSalesDetail(customer_id, reference_role_id);
	    HashMap<String, Object> salesDetailDataMap = new HashMap<String,Object>();
	    salesDetailDataMap.put(KEYWORD.SALES_DETAIL_DATA, records);
	    return salesDetailDataMap;
	}
	
	/**
	 * 取得销售的以业务员单位的集计页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<IroSalerSummaryCom> findSalerSalesSummary(String company_id, String reference_role_id){
    	HashMap<String,Object> param = new HashMap<String,Object>();
    	param.put(KEYWORD.COMPANY_ID, Long.parseLong(company_id));
    	param.put(KEYWORD.SALER_ROLE_ID, (long)ID.SALER_ROLE_ID);
    	param.put(KEYWORD.EDITOR_ROLE_ID, Long.valueOf(reference_role_id));
    	return iroSalesServiceMapper.findSalerSalesSummary(param);
    }
    
	/**
	 * 取得销售的以客户为单位的集计页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<IroCustomerSummaryCom> findCustomerSalesSummary(String saler_id, String reference_role_id){
    	HashMap<String,Object> param = new HashMap<String,Object>();
    	param.put(KEYWORD.SALER_ID, Long.parseLong(saler_id));
    	param.put(KEYWORD.EDITOR_ROLE_ID, Long.parseLong(reference_role_id));
    	return iroSalesServiceMapper.findCustomerSalesSummary(param);
    }
    
	/**
	 * 取得销售的详细页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<IroSalesDetailCom> findSalesDetail(String customer_id, String reference_role_id){
    	
    	HashMap<String,Object> param = new HashMap<String,Object>();
    	param.put(KEYWORD.CUSTOMER_ID, Long.parseLong(customer_id));
    	param.put(KEYWORD.EDITOR_ROLE_ID, Long.parseLong(reference_role_id));
    	return iroSalesServiceMapper.findSalesDetail(param);
    }
    
    @Transactional
    public boolean newSalesDetail(String saler_id, String customer_id, String role_id, JsonObject record) throws Exception{
    	IroSalesDetailCom iroSalesDetailCom = ConverterUtil.toObject(record, IroSalesDetailCom.class, 0);
    	if (iroSalesDetailCom == null) return false;
    	Long salesId = iroSalesRepository.findLastSeq() + 1;
    	Long orderId = iroOrderRepository.findLastSeq() + 1;
    	IroSalerCustomerEntity iroSalerCustomerEntity = iroSalerCustomerRlsRepository.findBySalerIdCustomerId(saler_id, customer_id);
    	iroOrderRepository.newEntity(orderId, iroSalesDetailCom.getOrder_name(), iroSalerCustomerEntity.getSaler_customer_rls_id());
    	iroSalesRepository.newEntity(salesId, orderId, Long.valueOf(role_id), iroSalesDetailCom);
    	return true;
    }
    
    @Transactional
    public boolean updateSalesDetail(JsonObject record) throws Exception{
    	IroSalesDetailCom iroSalesDetailCom = ConverterUtil.toObject(record, IroSalesDetailCom.class, 0);
    	if (iroSalesDetailCom == null) return false;
    	iroOrderRepository.updateEntity(iroSalesDetailCom);
    	iroSalesRepository.updateEntity(iroSalesDetailCom);
    	return true;
    }
    
    public boolean updatePhotocopy(Long sales_id, MultipartFile multipartFile){
    	IroSalesEntity iroSalesEntity = iroSalesRepository.findByPK(sales_id);
    	boolean isNormal = true;
    	//删除旧的文件
    	isNormal = iroStorageService.delete(iroSalesEntity.getPhotocopy());
    	if (isNormal == false) return isNormal;
    	//保存新的文件
    	iroStorageService.store(sales_id, multipartFile);
    	//更新数据库
    	iroSalesEntity.setPhotocopy(String.valueOf(sales_id) + SPECIALCHARACTER.DOT + multipartFile.getOriginalFilename());
    	return iroSalesEntity.update();
    }
    
    @Transactional
    public boolean deleteSalesDetail(JsonObject record) throws Exception{
    	IroSalesDetailCom iroSalesDetailCom = ConverterUtil.toObject(record, IroSalesDetailCom.class, 0);
    	if (iroSalesDetailCom == null) return false;
    	iroSalesRepository.deleteEntity(iroSalesDetailCom);
    	iroOrderRepository.deleteEntity(iroSalesDetailCom);
    	return true;
    }
    
}
