package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroCompanyMstDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4497911976961295317L;
	
	Long company_id; 
	String company_name;
	String company_system_name;
	Date usage_deadline;
	Integer user_limit;
	String domain_name;
	String landline_phone;
	String address;
	Timestamp create_datetime;
	Timestamp update_datetime;
	Integer del_flg;

}
