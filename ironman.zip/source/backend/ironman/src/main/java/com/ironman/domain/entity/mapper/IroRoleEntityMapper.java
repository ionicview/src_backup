package com.ironman.domain.entity.mapper;

import com.ironman.domain.generated.dto.IroRoleMstDto;

public interface IroRoleEntityMapper {
	int save(IroRoleMstDto iroRoleMstDto);
	int update(IroRoleMstDto iroRoleMstDto);
	int delete(IroRoleMstDto iroRoleMstDto);
}
