package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroJournalEntity;
import com.ironman.domain.generated.dto.IroJournalTrnDto;
import com.ironman.domain.repository.mapper.IroJournalRepositoryMapper;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroJournalRepository {

	@Autowired
	IroJournalRepositoryMapper iroJournalRepositoryMapper;
	
	public IroJournalEntity findByPK(IroJournalTrnDto iroJournalTrnDto){
		IroJournalEntity entity = EntityFactory.newEntity(IroJournalEntity.class);
		IroJournalTrnDto result = iroJournalRepositoryMapper.findByPK(iroJournalTrnDto);
		if (result == null) return null;
		entity.fromObject(result);
		return entity;
	}
}
