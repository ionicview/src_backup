package com.ironman.domain.constant;

public class FLG {
	final public static int DEBUG_LEVEL = 1;
	final public static String str_0 = "0";
	final public static String str_1 = "1";

}
