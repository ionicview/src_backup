package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroPurchaseEntity;
import com.ironman.domain.repository.mapper.IroPurchaseRepositoryMapper;

import com.ironman.domain.generated.dto.IroPurchaseTrnDto;

@Repository
public class IroPurchaseRepository {

	
	@Autowired
	IroPurchaseRepositoryMapper iroPurchaseRepositoryMapper;
	
	public IroPurchaseEntity findByPK(IroPurchaseTrnDto iroPurchaseTrnDto){
		return iroPurchaseRepositoryMapper.findByPK(iroPurchaseTrnDto);
	}
}
