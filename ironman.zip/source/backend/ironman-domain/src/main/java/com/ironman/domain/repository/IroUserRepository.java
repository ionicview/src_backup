package com.ironman.domain.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.generated.dto.IroUserMstDto;
import com.ironman.domain.repository.mapper.IroUserRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;

@Repository
public class IroUserRepository {

	@Autowired
	IroUserRepositoryMapper iroUserRepositoryMapper;
	

	public IroUserEntity findByPK(IroUserMstDto iroUserMstDto){
		return iroUserRepositoryMapper.findByPK(iroUserMstDto);
	}
	
	public IroUserEntity findByAccountPwdCompany(IroUserMstDto iroUserMstDto){
		return iroUserRepositoryMapper.findByAccountPwdCompany(iroUserMstDto);
	}
	
	public IroUserEntity findByAccountPwdCompany(String company_id, String account, String password){
		IroUserMstDto iroUserMstDto = BeanFactory.newBean(IroUserMstDto.class);
		iroUserMstDto.setCompany_id(Long.valueOf(company_id));
		iroUserMstDto.setAccount(account);
		iroUserMstDto.setPassword(password);
		return iroUserRepositoryMapper.findByAccountPwdCompany(iroUserMstDto);
	}
	
//	boolean updateLastProcessTime(IroUser iroUser);
//	List<IroMenu> getMenuData(IroUser iroUser);
//	List<IroSmartableSettingItems> getIroSmartableSettingsItem(Map<String,Object> iroUser);
}
