package com.ironman.domain.repository;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroUserStatusEntity;
import com.ironman.domain.generated.dto.IroUserStatusTrnDto;
import com.ironman.domain.repository.mapper.IroUserStatusRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroUserStatusRepository {
	@Autowired
	IroUserStatusRepositoryMapper iroUserStatusRepositoryMapper;
	

	public IroUserStatusEntity findByPK(IroUserStatusTrnDto iroUserStatusTrnDto){
		IroUserStatusEntity userStatusEntity = EntityFactory.newEntity(IroUserStatusEntity.class);
		IroUserStatusEntity dto = iroUserStatusRepositoryMapper.findByPK(iroUserStatusTrnDto);
		userStatusEntity.fromObject(dto);
		return userStatusEntity;
	}
	
	public IroUserStatusEntity findByPK(String user_id){
		IroUserStatusTrnDto iroUserStatusTrnDto = BeanFactory.newBean(IroUserStatusTrnDto.class);
		iroUserStatusTrnDto.setUser_id(Long.valueOf(user_id));
		return findByPK(iroUserStatusTrnDto);
	}
	
	public boolean newEntity(String user_id, String secretKey){
		IroUserStatusEntity userStatusEntity = EntityFactory.newEntity(IroUserStatusEntity.class);
		userStatusEntity.setUser_id(Long.valueOf(user_id));
		userStatusEntity.setSecret_key(secretKey);
		userStatusEntity.setUpdate_datetime(new Timestamp(System.currentTimeMillis()));
		return userStatusEntity.save();
	}
}
