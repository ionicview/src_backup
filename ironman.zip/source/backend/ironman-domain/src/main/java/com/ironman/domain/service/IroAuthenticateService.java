package com.ironman.domain.service;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ironman.domain.constant.FLG;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.entity.IroUserStatusEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;
import com.ironman.domain.generated.dto.IroUserMstDto;
import com.ironman.domain.generated.dto.IroUserStatusTrnDto;
import com.ironman.domain.repository.IroCompanyRepository;
import com.ironman.domain.repository.IroUserRepository;
import com.ironman.domain.repository.IroUserStatusRepository;
import com.rainbow.fw.constant.FWKEYWORD;
import com.rainbow.fw.constant.SECURITY;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;
import com.rainbow.fw.core.util.ToosUtil;
import com.rainbow.fw.security.EncryptService;

/**
 * 验证相关的服务类
 * 
 * @author Wang
 * 
 */
@Service
public class IroAuthenticateService {
	
	@Autowired
	IroCompanyRepository companyRepository;
	
	@Autowired
	IroUserRepository userRepository;
	
	@Autowired
	IroUserStatusRepository userStatusRepository;
	
	/**
	 * 根据公司域名获取公司系统名字
	 * 
	 * @param domain_name 域名
	 *     
	 * @return 符合条件的CompanyEntity
	 */
	public IroCompanyEntity findByDomainName(String domain_name) {
		
		return companyRepository.findByDomainName(domain_name);
	}
	
	public IroUserEntity findByAccountPwdCompany(String company_id,String account,String password) {
		
		return userRepository.findByAccountPwdCompany(company_id, account, password);
	}
	
	
	public JsonObject verifyUser(String company_id, String account, String password){
		
		String passwordHashValue = EncryptService.HashEncrypt(password);
		
		IroUserEntity entity = findByAccountPwdCompany(company_id, account, passwordHashValue);
		
		if (entity != null){
			//登录成功
			JsonObject json = new JsonObject();
			json.addProperty(KEYWORD.JWT, getJwt(company_id, String.valueOf(entity.getUser_id())));
			json.addProperty(KEYWORD.ROLE_ID, String.valueOf(entity.getRole_id()));
			json.addProperty(KEYWORD.USER_ID, String.valueOf(entity.getUser_id()));
			return json;
		}
		else{
			return null;
		}
	}
	
	/**
	 * 根据用户登录信息进行验证，验证成功后返回该用户的JWT (JSON Web Token) (类内部子方法) 
	 * 
	 * @param user_id 用户登录ID
	 *     
	 * @return 用户的JWT (JSON Web Token) 
	 */
	private String getJwt(String company_id, String user_id){
		
		IroUserStatusEntity userStatusEntity = userStatusRepository.findByPK(user_id);
		
		String secretKey =  EncryptService.getRandomString(SECURITY.SECRET_KEY_LEN);
		
		if (null == userStatusEntity){
			userStatusRepository.newEntity(user_id, secretKey);
		} else {
			userStatusEntity.update(secretKey);
		}
		
		String jwt = ToosUtil.genJwt(company_id, user_id, secretKey);
		return jwt;
	}
	
	/**
	 * 验证JWT是否有效
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户登录ID
	 * @param jwt 用户的JWT
	 *     
	 * @return JWT验证结果
	 */
	public boolean isValidJwt(String company_id, String user_id, String jwt){
		
		IroUserStatusEntity iroUserStatusEntity = userStatusRepository.findByPK(user_id);
		String secretKey = null;
		
		if (null == iroUserStatusEntity || null == iroUserStatusEntity.getSecret_key() || iroUserStatusEntity.isTimeout()){
			return false;
		} else {
			secretKey = iroUserStatusEntity.getSecret_key();
		}
		
		return ToosUtil.verifyJwt(jwt, secretKey);
		
	}
	
//	/**
//	 * 根据用户登录信息返回该用户的菜单
//	 * 
//	 * @param company_id 公司ID
//	 * @param user_id 用户登录ID
//	 *     
//	 * @return 用户的菜单
//	 */
//	public JsonObject getMenu(String company_id,String user_id){
//		return getMenuJson(company_id,user_id);
//	}
//	
//	/**
//	 * 根据用户登录信息返回该用户的菜单(类内部子方法)
//	 * 
//	 * @param company_id 公司ID
//	 * @param user_id 用户登录ID
//	 * @param resp 
//	 *     
//	 * @return 用户的菜单
//	 */
//    private JsonObject getMenuJson(String company_id,String user_id) {
//    	
//		    JsonObject jsonMenu = new JsonObject();
//		    JsonParser jsonParser = new JsonParser();
//		    JsonObject jsonMenuData = (JsonObject)jsonParser.parse(createMenuJson(company_id,user_id));
//		    jsonMenu.add(KEYWORD.MENU, jsonMenuData);		    
//	        return jsonMenu;
//    }
//	/**
//	 * 根据用户登录信息返回该用户的菜单(类内部子方法)
//	 * 
//	 * @param company_id 公司ID
//	 * @param user_id 用户登录ID
//	 *     
//	 * @return 用户的菜单
//	 */
//   private String createMenuJson(String company_id,String user_id){
//
//		IroUserEntity iroUserEntity = EntityFactory.newEntity(IroUserEntity.class);
//		IroUser iroUserPara = new IroUser();
//		iroUserPara.setCompany_id(Integer.valueOf(company_id));
//		iroUserPara.setUser_id(user_id);
//
//		List<IroMenu> iroMenuList = iroUserEntity.getMenuData(iroUserPara);
//		int index = 0;
//        Map<String,Object> rootPathMap = null;
//        List<Map<String,Object>> jsonObjects = new ArrayList<Map<String,Object>>();
//		for (IroMenu iromenu : iroMenuList){
//			if (index == 0){
//		        //菜单父路径
//			    rootPathMap = new HashMap<String,Object>();
//			    rootPathMap.put(KEYWORD.PATH,iromenu.getMenu_root_path());
//				}
//
//		//菜单路径
//		Map<String,Object> pathMap = new HashMap<String,Object>();
//		pathMap.put(KEYWORD.PATH,iromenu.getMenu_path());
//		//菜单Key
//		Map<String,Object> menuMap = new HashMap<String,Object>();
//		//菜单Data
//		Map<String,Object> menuDataMap = new HashMap<String,Object>();
//		menuDataMap.put(KEYWORD.TITLE, iromenu.getMenu_title());
//		menuDataMap.put(KEYWORD.ICON, iromenu.getMenu_icon());
//		menuDataMap.put(KEYWORD.SELECTED, (FLG.str_0.equals(iromenu.getMenu_selected())));
//		menuDataMap.put(KEYWORD.EXPANDED, (FLG.str_0.equals(iromenu.getMenu_expanded())));
//		menuDataMap.put(KEYWORD.ORDER, iromenu.getMenu_order());
//		
//		//菜单Key和菜单Data
//		menuMap.put(KEYWORD.MENU, menuDataMap);
//		
//		//菜单路径和菜单Key
//		pathMap.put(KEYWORD.DATA,menuMap);
//		
//		//菜单的JSON对象
//		        jsonObjects.add(pathMap);
//		        
//		        index++;
//		}
//		rootPathMap.put(KEYWORD.CHILDREN,jsonObjects);
//	    return rootPathMap.toString();
//	}
}
