package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroCustomerEntity;

import com.ironman.domain.generated.dto.IroCustomerMstDto;

public interface IroCustomerRepositoryMapper {
	
	IroCustomerEntity findByPK(IroCustomerMstDto iroCustomerMstDto);

}
