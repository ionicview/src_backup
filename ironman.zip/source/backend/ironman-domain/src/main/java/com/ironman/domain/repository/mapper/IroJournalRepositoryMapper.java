package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroJournalEntity;

import com.ironman.domain.generated.dto.IroJournalTrnDto;

public interface IroJournalRepositoryMapper {
	IroJournalEntity findByPK(IroJournalTrnDto iroJournalTrnDto);

}
