package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroOrderEntity;

import com.ironman.domain.generated.dto.IroOrderTrnDto;

public interface IroOrderRepositoryMapper {
	IroOrderEntity findByPK(IroOrderTrnDto iroOrderTrnDto);
}
