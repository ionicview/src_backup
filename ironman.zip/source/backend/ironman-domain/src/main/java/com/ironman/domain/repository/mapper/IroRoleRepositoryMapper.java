package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroRoleEntity;

import com.ironman.domain.generated.dto.IroRoleMstDto;

public interface IroRoleRepositoryMapper {
	IroRoleEntity findByPK(IroRoleMstDto iroRoleMstDto);
}
