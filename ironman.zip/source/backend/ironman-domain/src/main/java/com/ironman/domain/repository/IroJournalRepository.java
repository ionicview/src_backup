package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroJournalEntity;
import com.ironman.domain.generated.dto.IroJournalTrnDto;
import com.ironman.domain.repository.mapper.IroJournalRepositoryMapper;

@Repository
public class IroJournalRepository {

	@Autowired
	IroJournalRepositoryMapper iroJournalRepositoryMapper;
	
	public IroJournalEntity findByPK(IroJournalTrnDto iroJournalTrnDto){
		return iroJournalRepositoryMapper.findByPK(iroJournalTrnDto);
	}
}
