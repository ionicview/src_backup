package com.ironman.domain.repository.mapper;

import java.util.List;

import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.generated.dto.IroCustomerMstDto;
import com.ironman.domain.generated.dto.IroSalesTrnDto;
import com.ironman.domain.generated.dto.IroUserMstDto;

public interface IroSalesRepositoryMapper {
	
	IroSalesEntity findByPK(IroSalesTrnDto iroSalesTrnDto);
//	List<IroSalesEntity> findBySaler(IroUserMstDto iroUserMstDto);
//	List<IroSalesEntity> findByCustomer(IroCustomerMstDto iroCustomerMstDto);
}
