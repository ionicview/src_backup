package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;
import com.ironman.domain.repository.mapper.IroCompanyRepositoryMapper;
import com.rainbow.fw.core.factory.BeanFactory;
import com.rainbow.fw.core.factory.EntityFactory;

@Repository
public class IroCompanyRepository {

	@Autowired
	IroCompanyRepositoryMapper iroCompanyRepositoryMapper;
	
	public IroCompanyEntity findByPK(IroCompanyMstDto iroCompanyMstDto){
		return iroCompanyRepositoryMapper.findByPK(iroCompanyMstDto);
	}
	
	 
	public IroCompanyEntity findByDomainName(IroCompanyMstDto iroCompanyMstDto){
		return iroCompanyRepositoryMapper.findByDomainName(iroCompanyMstDto);
	}
	
	
	public IroCompanyEntity findByDomainName(String domainName){
		IroCompanyMstDto iroCompanyMstDto = BeanFactory.newBean(IroCompanyMstDto.class);
		iroCompanyMstDto.setDomain_name(domainName);
		return findByDomainName(iroCompanyMstDto);
	}
}
