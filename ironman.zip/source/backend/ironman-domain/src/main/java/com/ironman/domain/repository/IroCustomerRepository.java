package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroCustomerEntity;
import com.ironman.domain.repository.mapper.IroCustomerRepositoryMapper;

import com.ironman.domain.generated.dto.IroCustomerMstDto;



@Repository
public class IroCustomerRepository {
	@Autowired
	IroCustomerRepositoryMapper iroCustomerRepositoryMapper;
	
	public IroCustomerEntity findByPK(IroCustomerMstDto iroCustomerMstDto){
		return iroCustomerRepositoryMapper.findByPK(iroCustomerMstDto);
	}
}
