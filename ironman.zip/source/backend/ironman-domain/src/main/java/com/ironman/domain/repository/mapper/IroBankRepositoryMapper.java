package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroBankEntity;
import com.ironman.domain.generated.dto.IroBankMstDto;

public interface IroBankRepositoryMapper {
	IroBankEntity findByPK(IroBankMstDto iroBankMstDto);
}
