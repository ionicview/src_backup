package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroVendorEntity;
import com.ironman.domain.generated.dto.IroVendorMstDto;
import com.ironman.domain.repository.mapper.IroVendorRepositoryMapper;

@Repository
public class IroVendorRepository {

	@Autowired
	IroVendorRepositoryMapper iroVendorRepositoryMapper;
	

	IroVendorEntity findByPK(IroVendorMstDto iroVendorMstDto){
		return iroVendorRepositoryMapper.findByPK(iroVendorMstDto);
	}
}
