package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroOrderEntity;
import com.ironman.domain.repository.mapper.IroOrderRepositoryMapper;

import com.ironman.domain.generated.dto.IroOrderTrnDto;

@Repository
public class IroOrderRepository {
	@Autowired
	IroOrderRepositoryMapper iroOrderRepositoryMapper;
	
	public IroOrderEntity findByPK(IroOrderTrnDto iroOrderTrnDto){
		return iroOrderRepositoryMapper.findByPK(iroOrderTrnDto);
	}
}
