package com.ironman.domain.constant;

public class SPECIALCHARACTER {
	
	final public static String SLASH = "\'/\'";
	final public static String COMMA = ",";
	final public static String COLON = ":";
	final public static String POINT = ".";

}
