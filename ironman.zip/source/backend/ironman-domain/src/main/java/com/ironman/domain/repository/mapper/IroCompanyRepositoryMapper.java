package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;

public interface IroCompanyRepositoryMapper {
	IroCompanyEntity findByPK(IroCompanyMstDto iroCompanyMstDto);
	IroCompanyEntity findByDomainName(IroCompanyMstDto iroCompanyMstDto);
	
}
