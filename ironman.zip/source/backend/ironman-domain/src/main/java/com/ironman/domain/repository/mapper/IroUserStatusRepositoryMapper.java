package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroUserStatusEntity;
import com.ironman.domain.generated.dto.IroUserStatusTrnDto;

public interface IroUserStatusRepositoryMapper {

	IroUserStatusEntity findByPK(IroUserStatusTrnDto iroUserStatusTrnDto);
}
