package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroVendorEntity;

import com.ironman.domain.generated.dto.IroVendorMstDto;

public interface IroVendorRepositoryMapper {

	IroVendorEntity findByPK(IroVendorMstDto iroVendorMstDto);
}
