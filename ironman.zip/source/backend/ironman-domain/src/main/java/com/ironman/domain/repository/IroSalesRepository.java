package com.ironman.domain.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.generated.dto.IroCustomerMstDto;
import com.ironman.domain.generated.dto.IroSalesTrnDto;
import com.ironman.domain.generated.dto.IroUserMstDto;
import com.ironman.domain.repository.mapper.IroSalesRepositoryMapper;

@Repository
public class IroSalesRepository {
	
	@Autowired
	IroSalesRepositoryMapper iroSalesRepositoryMapper;
	
	public IroSalesEntity findByPK(IroSalesTrnDto iroSalesTrnDto){
		return iroSalesRepositoryMapper.findByPK(iroSalesTrnDto);
	}
	
//	public List<IroSalesEntity> findBySaler(IroUserMstDto iroUserMstDto) {
//		return iroSalesRepositoryMapper.findBySaler(iroUserMstDto);
//	}
//	
//	public List<IroSalesEntity> findByCustomer(IroCustomerMstDto iroCustomerMstDto) {
//		return iroSalesRepositoryMapper.findByCustomer(iroCustomerMstDto);
//	}
	
}
