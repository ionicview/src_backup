package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroRoleEntity;

import com.ironman.domain.generated.dto.IroRoleMstDto;
import com.ironman.domain.repository.mapper.IroRoleRepositoryMapper;

@Repository
public class IroRoleRepository {
	@Autowired
	IroRoleRepositoryMapper iroRoleRepositoryMapper;
	
	public IroRoleEntity findByPK(IroRoleMstDto iroRoleMstDto){
		return iroRoleRepositoryMapper.findByPK(iroRoleMstDto);
	}
}
