package com.ironman.domain.repository.mapper;

import java.util.List;

import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.generated.dto.IroUserMstDto;

public interface IroUserRepositoryMapper {

	IroUserEntity findByPK(IroUserMstDto iroUserMstDto);
	IroUserEntity findByAccountPwdCompany(IroUserMstDto iroUserMstDto);
}
