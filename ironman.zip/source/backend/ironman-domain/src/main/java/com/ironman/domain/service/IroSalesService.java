package com.ironman.domain.service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ironman.domain.constant.COMPONENT;
import com.ironman.domain.constant.FLG;
import com.ironman.domain.constant.KEYWORD;
import com.ironman.domain.entity.IroSalesEntity;
import com.ironman.domain.entity.IroUserEntity;
import com.ironman.domain.repository.IroSalesRepository;
import com.rainbow.fw.core.factory.EntityFactory;
import com.rainbow.fw.core.util.ToosUtil;
import com.rainbow.fw.datastructure.KVnode;
import com.rainbow.fw.datastructure.KVtree;

/**
 * 销售相关的服务类
 * 
 * @author Wang
 * 
 */
@Service
public class IroSalesService {
	
	@Autowired
	IroSalesRepository salesRepository;
	
//	/**
//	 * 取得销售的以业务员为单位的集计页面的列信息
//	 * 
//	 * @param company_id 公司ID
//	 * @param user_id 用户ID
//	 *     
//	 * @return 列信息
//	 */
//	public JsonObject getSalerSummarySetting(String company_id,String user_id){
//	    return createSalerSummarySettingJson(company_id,user_id);
//	}
	
	/**
	 * 取得销售的以业务员为单位的集计页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 数据信息
	 */
	public JsonObject getSalerSummaryData(String company_id, String user_id){
	    List<Map<String,Object>> records = createSalerSummaryDataJson(company_id,user_id);
	    HashMap<String, Object> salerSummaryDataMap = new HashMap<String,Object>();
	    salerSummaryDataMap.put(KEYWORD.SALER_SUMMARY_DATA, records);
	    JsonObject salerSummaryData = (JsonObject) new Gson().toJsonTree(salerSummaryDataMap);
	  
        return salerSummaryData;
	}
	
//	/**
//	 * 取得销售的以客户为单位的集计页面的列信息
//	 * 
//	 * @param company_id 公司ID
//	 * @param user_id 用户ID
//	 *     
//	 * @return 列信息
//	 */
//	public JsonObject getCustomerSummarySetting(String company_id,String user_id){
//	    return createCustomerSummarySettingJson(company_id,user_id);
//	}
	
	/**
	 * 取得销售的详细页面数据信息
	 * 
	 * @param company_id 公司ID
	 * @param salerId 业务员ID
	 *     
	 * @return 数据信息
	 */
	public JsonObject getCustomerSummaryData(String company_id,String salerId){
	    List<Map<String,Object>> records = createCustomerSummaryDataJson(company_id,salerId);
	    HashMap<String, Object> salerSummaryDataMap = new HashMap<String,Object>();
	    salerSummaryDataMap.put(KEYWORD.SALER_CUSTOMER_SUMMARY_DATA, records);
	    JsonObject salerSummaryData = (JsonObject) new Gson().toJsonTree(salerSummaryDataMap);
        return salerSummaryData;
	}
	
	/**
	 * 取得销售的详细页面的列信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 列信息
	 */
//	public JsonObject getSalesDetailSetting(String company_id,String user_id){
//	    return createSalesDetailSettingJson(company_id,user_id);
//	}
	
	/**
	 * 取得销售的详细页面的数据信息
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 数据信息
	 */
	public JsonObject getSalesDetailData(String company_id,String salerId,String customer_id){
	    List<Map<String,Object>> records = createSalesDetailDataJson(company_id,salerId,customer_id);
	    HashMap<String, Object> salesDetailDataMap = new HashMap<String,Object>();
	    salesDetailDataMap.put(KEYWORD.SALES_DETAIL_DATA, records);
	    JsonObject salesDetailData = (JsonObject) new Gson().toJsonTree(salesDetailDataMap);
        return salesDetailData;
	}
	
	/**
	 * 把销售详细信息插入销售表
	 * 
	 * @param iroSalesJsonStr 销售详细信息
	 *     
	 * @return 插入成功与否
	 */
//	public boolean insertSales(String iroSalesJsonStr){
//		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
//		return iroSalesEntity.insertSales(jsonStrToObject(iroSalesJsonStr));
//	}
	
	/**
	 * 把指定的销售详细信息从销售表中删除
	 * 
	 * @param sales_id 
	 * @param company_id 
	 * @param product_id 
	 *     
	 * @return 删除成功与否
	 */
//	public boolean deleteByPrimaryKey(String sales_id,String company_id,String product_id){
//		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
//		IroSales iroSales = new IroSales();
//		iroSales.setSales_id(Integer.valueOf(sales_id));
//		iroSales.setCompany_id(Integer.valueOf(company_id));
//		iroSales.setProduct_id(Integer.valueOf(product_id));
//		return iroSalesEntity.deleteByPrimaryKey(iroSales);
//	}
	
	/**
	 * 把指定的销售详细信息进行修改销售表
	 * 
	 * @param iroSalesJsonStr 销售详细信息
	 *     
	 * @return 修改成功与否
	 */
//	public boolean updateByPrimaryKey(String iroSalesJsonStr){
//		IroSalesEntity iroSalesEntity = EntityFactory.newEntity(IroSalesEntity.class);
//		return iroSalesEntity.updateByPrimaryKey(jsonStrToObject(iroSalesJsonStr));
//	}
	
	/**
	 * 取得销售的以业务员为单位的集计页面的列信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 列信息
	 */
//	private JsonObject createSalerSummarySettingJson(String company_id,String user_id){
//		IroUserEntity iroUserEntity = EntityFactory.newEntity(IroUserEntity.class);
//		Map<String,Object> mapPram = new HashMap<String,Object>();
//		mapPram.put(KEYWORD.SMARTABLE_SETTING_ITEM_ID, COMPONENT.SALER_SUMMARY_TABLE_ID);//营业员
//		mapPram.put(KEYWORD.COMPANY_ID, Integer.valueOf(company_id));
//		mapPram.put(KEYWORD.USER_ID, user_id);
//		List<IroSmartableSettingItems> irocolumnsList = iroUserEntity.getIroSmartableSettingsItem(mapPram);
//
//	    KVtree<String,Object> kvtree = new KVtree<String,Object>();
//		for (IroSmartableSettingItems iroColumns : irocolumnsList){
//			long id = iroColumns.getSmartable_setting_item_id();
//			String key = iroColumns.getSmartable_setting_item_key();
//			String value = iroColumns.getSmartable_setting_item_value();
//			long parentId = iroColumns.getParent_id();
//			kvtree.addNode(key, value, id, parentId);
//		}
//		KVnode<String,Object> node = kvtree.node(KEYWORD.SALER_SUMMARY_SETTING);
//	    JsonObject json = kvtree.toJson(node);
//	    if (FLG.DEBUG_LEVEL > 0) System.out.println(json);
//        return json;
//    }
	
	/**
	 * 取得销售的以顾客为单位的集计页面的列信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 列信息
	 */
//	private JsonObject createCustomerSummarySettingJson(String company_id,String user_id){
//		IroUserEntity iroUserEntity = EntityFactory.newEntity(IroUserEntity.class);
//		Map<String,Object> mapPram = new HashMap<String,Object>();
//		mapPram.put(KEYWORD.SMARTABLE_SETTING_ITEM_ID, COMPONENT.SALER_CUSTOMER_SUMMARY_TABLE_ID);//顾客
//		mapPram.put(KEYWORD.COMPANY_ID, Integer.valueOf(company_id));
//		mapPram.put(KEYWORD.USER_ID, user_id);
//		List<IroSmartableSettingItems> irocolumnsList = iroUserEntity.getIroSmartableSettingsItem(mapPram);
//
//	    KVtree<String,Object> kvtree = new KVtree<String,Object>();
//		for (IroSmartableSettingItems iroColumns : irocolumnsList){
//			long id = iroColumns.getSmartable_setting_item_id();
//			String key = iroColumns.getSmartable_setting_item_key();
//			String value = iroColumns.getSmartable_setting_item_value();
//			long parentId = iroColumns.getParent_id();
//			kvtree.addNode(key, value, id, parentId);
//		}
//		KVnode<String,Object> node = kvtree.node(KEYWORD.SALER_CUSTOMER_SUMMARY_SETTING);
//	    JsonObject json = kvtree.toJson(node);
//	    if (FLG.DEBUG_LEVEL > 0) System.out.println(json);
//        return json;
//    }
	
	/**
	 * 取得销售的详细页面的列信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 *     
	 * @return 列信息
	 */
//	private JsonObject createSalesDetailSettingJson(String company_id,String user_id){
//		IroUserEntity iroUserEntity = EntityFactory.newEntity(IroUserEntity.class);
//		Map<String,Object> mapPram = new HashMap<String,Object>();
//		String summarySetting = "";
//
//		mapPram.put(KEYWORD.SMARTABLE_SETTING_ITEM_ID, COMPONENT.SALES_DETAIL_TABLE_ID);//详细页面
//		summarySetting = KEYWORD.SALES_DETAIL_SETTING;
//
//		mapPram.put(KEYWORD.COMPANY_ID, Integer.valueOf(company_id));
//		mapPram.put(KEYWORD.USER_ID, user_id);
//		List<IroSmartableSettingItems> irocolumnsList = iroUserEntity.getIroSmartableSettingsItem(mapPram);
//
//	    KVtree<String,Object> kvtree = new KVtree<String,Object>();
//		for (IroSmartableSettingItems iroColumns : irocolumnsList){
//			long id = iroColumns.getSmartable_setting_item_id();
//			String key = iroColumns.getSmartable_setting_item_key();
//			Object value = iroColumns.getSmartable_setting_item_value();
//			long parentId = iroColumns.getParent_id();
//			kvtree.addNode(key, value, id, parentId);
//		}
//		
//		// 参考代码
//		//取出选项列表，付给节点，效率比较低，最好在上面生成树的时候，就把选项列表付给节点
//		// 厂商， 是否含税 都需要添加选项列表
////		List<String> keyList = new ArrayList<String>();
////		keyList.add("sales_detail_setting");
////		keyList.add("settings");
////		keyList.add("columns");
////		keyList.add("vendor");
////		keyList.add("editor");
////		keyList.add("config");
////		keyList.add("list");
////		KVnode<String,Object> vendorListNode = kvtree.node(keyList);
////		List<Map<String,Object>> vendorList = new ArrayList<Map<String,Object>>();
////        Map<String,Object> map1 = new HashMap<String,Object>();
////        map1.put("value", "Antonette");
////        map1.put("title", "Antonette");
////        Map<String,Object> map2 = new HashMap<String,Object>();
////        map2.put("value", "Bret");
////        map2.put("title", "Bret");
////        Map<String,Object> map3 = new HashMap<String,Object>();
////        map3.put("value", "Samantha");
////        map3.put("title", "Samantha");
////		vendorList.add(map1);
////		vendorList.add(map2);
////		vendorList.add(map3);
////		vendorListNode.setValue(vendorList);
//		////////////////////////////////////////////////////////////////////////
//		
//		KVnode<String,Object> node = kvtree.node(summarySetting);
//	    JsonObject json = kvtree.toJson(node);
//	    if (FLG.DEBUG_LEVEL > 0) System.out.println(json);
//        return json;
//    }
	
	/**
	 * 取得销售的以业务员单位的集计页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<Map<String,Object>> createSalerSummaryDataJson(String company_id,String salerId){
    	

//		IroUser iroUserPara = new IroUser();
//		iroUserPara.setCompany_id(Integer.valueOf(company_id));
//		List<IroSales> iroSalesList = null;
//		
//		 iroUserPara.setRole_id(KEYWORD.SALER_ROLE_ID);
//		 iroSalesList = salesRepository.getSalesInfoBysaler(iroUserPara);
//		
    	List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
//    	
//		for (IroSales irosales:iroSalesList){
//			if(null == irosales) return null;
//			Map<String,Object> irosalesMap = new HashMap<String,Object>();
//			
//			irosalesMap.put(KEYWORD.SALER_ID, irosales.getUser_id());//营业员ID
//			irosalesMap.put(KEYWORD.SALER, irosales.getName());//营业员
//
//			BigDecimal receivableAmount = ToosUtil.doubleFormat(2, irosales.getReceivable_amount()) ;
//			irosalesMap.put(KEYWORD.PHONE, irosales.getMobile_phone());//电话
//			irosalesMap.put(KEYWORD.PAYABLE_INVOICE, irosales.getPayable_invoice());//应开发票总金额
//			irosalesMap.put(KEYWORD.PAID_INVOICE, irosales.getInvoice_amount());//已开发票总金额
//			irosalesMap.put(KEYWORD.UNPAID_INVOICE, irosales.getPayable_invoice().subtract(irosales.getInvoice_amount()));//剩余未开发票总计=应开发票总金额-已开发票总金额
//			irosalesMap.put(KEYWORD.RECEIVABLE_AMOUNT, receivableAmount);//应收账款总金额=数量*单价
//			irosalesMap.put(KEYWORD.RECEIED_AMOUNT, irosales.getAmount());//已收账款总金额
//			irosalesMap.put(KEYWORD.UNCOLLECTED_AMOUNT, receivableAmount.subtract(irosales.getAmount()));//欠款总金额=应收账款总金额-已收账款总金额
//    		list.add(irosalesMap);
//		}
        return list;
    }
    
	/**
	 * 取得销售的以客户为单位的集计页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<Map<String,Object>> createCustomerSummaryDataJson(String company_id,String salerId){
    	
		
    	List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
//		IroUser iroUserPara = new IroUser();
//		iroUserPara.setCompany_id(Integer.valueOf(company_id));
//		iroUserPara.setUser_id(salerId);
//		List<IroSales> iroSalesList = salesRepository.getSalesInfoBycustomer(iroUserPara);
//    	
//		for (IroSales irosales:iroSalesList){
//			if(null == irosales) return null;
//			Map<String,Object> irosalesMap = new HashMap<String,Object>();
//			BigDecimal receivableAmount = ToosUtil.doubleFormat(2, irosales.getReceivable_amount()) ;
//			irosalesMap.put(KEYWORD.CUSTOMER, irosales.getName());//
//			irosalesMap.put(KEYWORD.CUSTOMER_ID, irosales.getCustomer_id());//
//			irosalesMap.put(KEYWORD.PHONE, irosales.getMobile_phone());//电话
//			irosalesMap.put(KEYWORD.PAYABLE_INVOICE, irosales.getPayable_invoice());//应开发票总金额
//			irosalesMap.put(KEYWORD.PAID_INVOICE, irosales.getInvoice_amount());//已开发票总金额
//			irosalesMap.put(KEYWORD.UNPAID_INVOICE, irosales.getPayable_invoice().subtract(irosales.getInvoice_amount()));//剩余未开发票总计=应开发票总金额-已开发票总金额
//			irosalesMap.put(KEYWORD.RECEIVABLE_AMOUNT, receivableAmount);//应收账款总金额=数量*单价
//			irosalesMap.put(KEYWORD.RECEIED_AMOUNT, irosales.getAmount());//已收账款总金额
//			irosalesMap.put(KEYWORD.UNCOLLECTED_AMOUNT, receivableAmount.subtract(irosales.getAmount()));//欠款总金额=应收账款总金额-已收账款总金额
//    		list.add(irosalesMap);
//		}
        return list;
    }
    
	/**
	 * 取得销售的详细页面的数据信息（子方法）
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户ID
	 * @param roleFlag 业务员画面或者客户画面
	 *     
	 * @return 数据信息
	 */
    private List<Map<String,Object>> createSalesDetailDataJson(String company_id,String salerId,String customer_id){
    	
		
    	List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
//		IroUser iroUserPara = new IroUser();
//		iroUserPara.setCompany_id(Integer.valueOf(company_id));
//		List<IroSales> iroSalesList = null;
//		
//		 iroUserPara.setUser_id(salerId);
//		 iroUserPara.setCompany_id(Integer.valueOf(company_id));
//		 iroUserPara.setCustomer_id(Integer.valueOf(customer_id));
//		 iroSalesList = salesRepository.getSalesDetail(iroUserPara);
//		
//    	/////////////////////todo
//		for (IroSales irosales:iroSalesList){
//			if(null == irosales) return null;
//			Map<String,Object> irosalesMap = new LinkedHashMap<String,Object>();
//			
//			//irosalesMap.put(KEYWORD.SALER_ID, irosales.getUser_id());
//			irosalesMap.put(KEYWORD.SALES_ID, irosales.getSales_id());
//			irosalesMap.put(KEYWORD.COMPANY_ID, irosales.getCompany_id());
//			irosalesMap.put(KEYWORD.PRODUCT_ID, irosales.getProduct_id());
//			irosalesMap.put(KEYWORD.PRODUCT_NAME, irosales.getProduct_name());
//			irosalesMap.put(KEYWORD.SPEC, irosales.getSpec());
//			
//			irosalesMap.put(KEYWORD.CUSTOMER_ID, irosales.getCustomer_id());
//			irosalesMap.put(KEYWORD.ORDER_NO, irosales.getOrder_no());
//			irosalesMap.put(KEYWORD.USER_ID, irosales.getUser_id());
//			irosalesMap.put(KEYWORD.SALE_DATE, ToosUtil.formatYmd(irosales.getSale_date()));
//			irosalesMap.put(KEYWORD.TRANSACTIONTYPE, irosales.getTransactionType());
//			irosalesMap.put(KEYWORD.QUANTITY, irosales.getQuantity());
//			irosalesMap.put(KEYWORD.PRICE, irosales.getPrice());
//			irosalesMap.put(KEYWORD.PAYABLE_INVOICE, irosales.getPayable_invoice());
//			irosalesMap.put(KEYWORD.PAY_DATE, ToosUtil.formatYmd(irosales.getPay_date()));
//			irosalesMap.put(KEYWORD.CASH, irosales.getCash());
//			irosalesMap.put(KEYWORD.BILL, irosales.getBill());
//			irosalesMap.put(KEYWORD.T_T, irosales.getT_t());
//			irosalesMap.put(KEYWORD.ACCEPTANCE, irosales.getAcceptance());
//			irosalesMap.put(KEYWORD.AMOUNT, irosales.getAmount());
//			irosalesMap.put(KEYWORD.PAYER, irosales.getPayer());
//			irosalesMap.put(KEYWORD.ISSUE_INVOICE_DATE, ToosUtil.formatYmd(irosales.getIssue_invoice_date()));
//			irosalesMap.put(KEYWORD.INVOICE_AMOUNT, irosales.getInvoice_amount());
//			irosalesMap.put(KEYWORD.BUYER, irosales.getBuyer());
//			irosalesMap.put(KEYWORD.INVOICE_NO, irosales.getInvoice_no());
//			irosalesMap.put(KEYWORD.PHOTOCOPY, irosales.getPhotocopy());
//			BigDecimal receivableAmount = ToosUtil.doubleFormat(2, irosales.getQuantity().multiply(irosales.getPrice())) ;
//			irosalesMap.put(KEYWORD.RECEIVABLE_AMOUNT, receivableAmount);
//			irosalesMap.put(KEYWORD.SALER_ID, irosales.getUser_id());//营业员ID
//			irosalesMap.put(KEYWORD.SALER, irosales.getName());//营业员
//			irosalesMap.put(KEYWORD.PHONE, irosales.getMobile_phone());
//			irosalesMap.put(KEYWORD.PAYABLE_INVOICE, irosales.getPayable_invoice());
//			irosalesMap.put(KEYWORD.PAID_INVOICE, irosales.getInvoice_amount());
//			irosalesMap.put(KEYWORD.UNPAID_INVOICE, irosales.getPayable_invoice().subtract(irosales.getInvoice_amount()));
//			irosalesMap.put(KEYWORD.RECEIED_AMOUNT, irosales.getAmount());
//			irosalesMap.put(KEYWORD.UNCOLLECTED_AMOUNT, receivableAmount.subtract(irosales.getAmount()));
//    		list.add(irosalesMap);
//		}
        return list;
    }
    
//    private IroSales jsonStrToObject(String jsonStr){
//    	String jsonext = jsonStr.replaceAll("\"\"", "null");
//    	JsonParser parser = new JsonParser();
//    	Gson gson = new Gson();
//    	IroSales iroSales = new IroSales();
//    	JsonElement jsonElement = parser.parse(jsonext);
//    	iroSales = gson.fromJson(jsonElement, IroSales.class);
//    	return iroSales;
//    }
}
