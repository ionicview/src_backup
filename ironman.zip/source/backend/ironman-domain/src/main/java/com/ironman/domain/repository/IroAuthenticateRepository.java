package com.ironman.domain.repository;

import org.springframework.stereotype.Repository;

@Repository
public class IroAuthenticateRepository {

}
