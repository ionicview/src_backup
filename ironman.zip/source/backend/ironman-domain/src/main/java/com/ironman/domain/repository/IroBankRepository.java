package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroBankEntity;
import com.ironman.domain.entity.IroCompanyEntity;
import com.ironman.domain.generated.dto.IroCompanyMstDto;
import com.ironman.domain.repository.mapper.IroBankRepositoryMapper;
import com.ironman.domain.generated.dto.IroBankMstDto;

@Repository
public class IroBankRepository {
	
	@Autowired
	IroBankRepositoryMapper iroBankRepositoryMapper;
	
	public IroBankEntity findByPK(IroBankMstDto iroBankMstDto){
		return iroBankRepositoryMapper.findByPK(iroBankMstDto);
	}
	

}
