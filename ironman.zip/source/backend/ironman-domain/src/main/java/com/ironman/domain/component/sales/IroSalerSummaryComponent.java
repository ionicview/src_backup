package com.ironman.domain.component.sales;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroSalerSummaryComponent implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8985712396496534717L;
	
	String saler;
	String phone;
	double payable_invoice;
	double paid_invoice;
	double unpaid_invoice;
	double receivable_amount;
	double received_amount;
	double uncollected_amount;
}
