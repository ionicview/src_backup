package com.ironman.domain.repository.mapper;

import com.ironman.domain.entity.IroPurchaseEntity;

import com.ironman.domain.generated.dto.IroPurchaseTrnDto;

public interface IroPurchaseRepositoryMapper {
	IroPurchaseEntity findByPK(IroPurchaseTrnDto iroPurchaseTrnDto);
}
