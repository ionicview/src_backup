package com.ironman.domain.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ironman.domain.entity.IroExpensesEntity;
import com.ironman.domain.generated.dto.IroExpensesTrnDto;
import com.ironman.domain.repository.mapper.IroExpensesRepositoryMapper;

@Repository
public class IroExpensesRepository {
	
	@Autowired
	IroExpensesRepositoryMapper iroExpensesRepositoryMapper;
	
	public IroExpensesEntity findByPK(IroExpensesTrnDto iroExpensesTrnDto){
		return iroExpensesRepositoryMapper.findByPK(iroExpensesTrnDto);
	}
}
