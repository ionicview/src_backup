package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroSalerCustomerRlsDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1764064992486581254L;
	long saler_customer_rls_id;
	long user_id;
	long customer_id;

}
