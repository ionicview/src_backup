package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroRoleMstDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7941603030658461034L;
	
	long role_id;
	String role_name;
	Timestamp create_datetime;
	Timestamp update_datetime;
	int del_flg;

}
