package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroExpensesTrnDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8233706304223267582L;
	long expenses_id;
	long order_id;
	double expenses_amount; 
	String expenses_usage;
	String remarks;
}
