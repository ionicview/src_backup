package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class IroUserMstDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5019019129976617072L;
	
	long user_id;
	long company_id;
	long role_id;
	String account;
	String password;
	String name;
	String sex;
	String landline_phone;
	String mobile_phone;
	String address;
	String email;
	Timestamp last_login_datetime;
	long login_count;
	Timestamp create_datetime;
	Timestamp update_datetime;
	int del_flg;

}
