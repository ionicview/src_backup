package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroOrderTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5826897269314444789L;
	long order_id;
	long saler_id;
	long customer_id;
	String order_name;

}
