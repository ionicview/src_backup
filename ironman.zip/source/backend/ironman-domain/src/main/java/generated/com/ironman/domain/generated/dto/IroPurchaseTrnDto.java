package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class IroPurchaseTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2956493843742183461L;
	
	long purchase_id;
	long editor_id;
	long order_id;
	long vendor_id;
	Date purchase_date;
	String customer_name;
	String product_name;
	String spec;
	double quantity;
	double price;
	String transaction_type;
	Date payment_date;
	double cash;
	double bill;
	double t_t;
	double acceptance;
	String payer;
	String invoice_requirement;
	Date issue_date;
	double invoice_amount;
	String seller;
	String invoice_no;
	String photocopy;
	

}
