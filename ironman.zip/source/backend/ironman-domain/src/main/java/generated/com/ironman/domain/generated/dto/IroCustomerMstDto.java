package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroCustomerMstDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7597505246688046316L;
	
	long customer_id;
	String finance_contact;
	String finance_phone;
}
