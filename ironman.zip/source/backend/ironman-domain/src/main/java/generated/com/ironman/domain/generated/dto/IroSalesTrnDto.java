package com.ironman.domain.generated.dto;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class IroSalesTrnDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2336421802991485121L;
	
	long sales_id;
	long editor_id;
	long order_id;
	Date sales_date;
	String vendor_name;
	String transaction_type;
	String product_name;
	String spec;
	Double quantity;
	Double price;
	Date payment_date;
	Double cash;
	Double bill;
	Double t_t;
	Double acceptance;
	String payer;
	Date issue_date;
	Double invoice_amount;
	String buyer;
	String invoice_no;
}
