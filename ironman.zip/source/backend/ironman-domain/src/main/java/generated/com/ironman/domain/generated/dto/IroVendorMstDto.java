package com.ironman.domain.generated.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class IroVendorMstDto implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -1291987271596815797L;
	long vendor_id;
	double estimated_payment;
	double estimated_invoice;
	String finance_contact;
	String finance_phone;
	String remarks;

}
