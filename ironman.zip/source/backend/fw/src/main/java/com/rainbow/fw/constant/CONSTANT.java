package com.rainbow.fw.constant;

public class CONSTANT {
	
	final public static int TIMEOUTSPAN = 1000*60*30;

}
