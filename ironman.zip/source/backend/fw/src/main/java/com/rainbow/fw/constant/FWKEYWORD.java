package com.rainbow.fw.constant;

public class FWKEYWORD {
	final public static String JWT = "jwt";
	final public static String PATH = "path";
	final public static String TITLE = "title";
	final public static String ICON = "icon";
	final public static String SELECTED = "selected";
	final public static String EXPANDED = "expanded";
	final public static String ORDER = "order";
	final public static String MENU = "menu";
	final public static String DATA = "data";
	final public static String CHILDREN = "children";
	final public static String TYPE = "type";
	final public static String ALGORITHM = "algorithm";
	final public static String SHA256 = "sha256";
	

	final public static String DOT = ".";
	final public static String LOGOUT = "general.menu.logout";
	final public static String URL = "url";
	final public static String SLASH = "\'/\'";
	final public static String COMMA = ",";
	final public static String COLON = ":";
	
	final public static String AUTHENTICATE = "/authenticate";
	final public static String VERIFYUSER = "verifyuser";
	final public static String MENUFORM = "menuForm";
	final public static String GETSYSTEMNAME = "getsystemname";
	final public static String GETMENU = "getmenu";
	final public static String DOMAIN_NAME = "domain_name";
	final public static String COMPANY_ID = "company_id";
	final public static String USER_ID = "user_id";
	final public static String PASSWORD = "password";
	final public static String SALER = "saler";
	final public static String COLUMNS = "columns";
	
	final public static String SHA_256 = "SHA-256";
	final public static String HMACSHA256 = "HmacSHA256";
	
	final public static String ENCODE = "encode";
	final public static String DATETIME_FORMAT = "yyyy-MM-dd";
	final public static String NOW_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	final public static String DATETIME_STR = "dateTime";
	


}


