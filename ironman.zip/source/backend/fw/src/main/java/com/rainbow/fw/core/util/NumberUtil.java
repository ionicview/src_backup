package com.rainbow.fw.core.util;

import java.math.BigDecimal;

public class NumberUtil {
	/**
	 * 把浮点型数据进行四舍五入格式化并返回的方法
	 * 
	 * @param num 小数点后保留几位
	 * @param value 要格式化的值
	 *     
	 * @return 格式化后的值
	 */
	public static BigDecimal doubleFormat(int num, BigDecimal value){
		if (null == value) return BigDecimal.ZERO;

		BigDecimal  bd2 = value.setScale(2,BigDecimal.ROUND_HALF_UP);

		return bd2;
	}
}
