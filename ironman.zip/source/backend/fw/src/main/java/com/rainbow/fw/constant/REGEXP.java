package com.rainbow.fw.constant;

public class REGEXP {
	final public static String DOT = "[.]";
	final public static String DOUBLEQUOTATION = "\"\"";
}
