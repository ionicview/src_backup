package com.rainbow.fw.core.factory;

import com.rainbow.fw.web.context.ContextProvider;

public class EntityFactory {

	public static <T> T newEntity(Class<T> cls) {
		T entity = ContextProvider.getBean(cls);

		return entity;
	}
}
