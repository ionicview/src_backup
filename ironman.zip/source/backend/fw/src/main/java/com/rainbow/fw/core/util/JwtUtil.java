package com.rainbow.fw.core.util;

import com.google.gson.JsonObject;
import com.rainbow.fw.constant.FWKEYWORD;
import com.rainbow.fw.constant.REGEXP;
import com.rainbow.fw.security.EncryptService;

public class JwtUtil {
	/**
	 * 获取JWT的字符串方法
	 * 
	 * @param company_id 公司ID
	 * @param user_id 用户登录ID
	 * @param secretKey 用户的私钥
	 *     
	 * @return JWT
	 */
	public static String genJwt(String company_id,String user_id,String secretKey){
	    JsonObject jwtHeader = new JsonObject();
	    JsonObject jwtPlayload = new JsonObject();
	    //JWT第一部分我们称它为头部（header)
	    String jwtHeaderBase64 = null;
	    //JWT第二部分我们称其为载荷
	    String jwtPlayloadBase64 = null;
	    //JWT第三部分是签证（signature)
	    String jwtHeaderPlayloadHmacsha256 = null;
	    try {
	    	//定义jwt的头部
	    	jwtHeader.addProperty(FWKEYWORD.TYPE, FWKEYWORD.JWT);
	    	jwtHeader.addProperty(FWKEYWORD.ALGORITHM, FWKEYWORD.SHA256);
	    	//定义一个payload:
	    	jwtPlayload.addProperty(FWKEYWORD.USER_ID, user_id);
	    	jwtPlayload.addProperty(FWKEYWORD.COMPANY_ID, company_id);
		    //将头部进行base64加密
	    	jwtHeaderBase64 = EncryptService.encodeBase64(jwtHeader.toString().getBytes());
	    	//将payload进行base64加密
	    	jwtPlayloadBase64 = EncryptService.encodeBase64(jwtPlayload.toString().getBytes());
	    	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		StringBuilder jwtBuf = new StringBuilder();
		jwtBuf.append(jwtHeaderBase64);
		jwtBuf.append(FWKEYWORD.DOT);
		jwtBuf.append(jwtPlayloadBase64);
		//对第三部分签证信息进行HMACSHA256加密 -> (header (base64后的),payload (base64后的),secret)
		jwtBuf.append(FWKEYWORD.DOT);
		jwtHeaderPlayloadHmacsha256 = EncryptService.HMACSHA256(new String(jwtHeaderBase64+jwtPlayloadBase64).getBytes(), secretKey.getBytes());
		jwtBuf.append(jwtHeaderPlayloadHmacsha256);

		return jwtBuf.toString();
	}
	
	public static boolean verifyJwt(String jwt, String secretKey){
		
		String jwtParts[] = jwt.split(REGEXP.DOT);
		if (jwtParts == null || jwtParts.length < 2) return false;
		String jwtHeader = jwtParts[0];
		String jwtPlayload = jwtParts[1];
		String jwtHashValue = jwtParts[2];

		boolean isValid = EncryptService.HMACSHA256(new String(jwtHeader+jwtPlayload).getBytes(), secretKey.getBytes()).equals(jwtHashValue);

		return isValid;
	}
}
