package com.rainbow.fw.core.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.rainbow.fw.constant.CONSTANT;
import com.rainbow.fw.constant.FWKEYWORD;

public class DateTimeUtil {
	
	/**
	 * 比较两个日期方法
	 * 
	 * @param time1 比较的日期
	 * @param time2 比较的日期
	 *     
	 * @return 比较日期的结果
	 */
    public static boolean dateTimeCompare(String time1,String time2,int number) 
    {  
        //如果想比较日期则写成"yyyy-MM-dd"就可以了  
        SimpleDateFormat sdf=new SimpleDateFormat(FWKEYWORD.NOW_DATETIME_FORMAT);  
        //将字符串形式的时间转化为Date类型的时间  
        Date dateTime1 = new Date();
        Date dateTime2 = new Date();
		try {
			dateTime1 = sdf.parse(time1);
			dateTime2 = sdf.parse(time2);  
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        if(dateTime1.getTime() - dateTime2.getTime() < number ) {
            return true; 
        }
        else 
            return false; 
    }
	
	public static boolean millisecondsCompare(long startMilliseconds, long endMilliseconds, long span){
		return endMilliseconds - startMilliseconds > span;
	}
	
	public static boolean timestampCompare(Timestamp startDateTime, long span){
		return millisecondsCompare(startDateTime.getTime(), System.currentTimeMillis(), span);
	}
	
	public static String formatYmd(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat(FWKEYWORD.DATETIME_FORMAT);  
        String dateStr = sdf.format(date);
        return dateStr;
	}
	
	/**
	 * 返回系统当前时间
	 * @return 系统当前时间
	 */
	public static String getNowTime(){
		SimpleDateFormat nowTime=new SimpleDateFormat(FWKEYWORD.NOW_DATETIME_FORMAT);
		String nowTimeStr = nowTime.format(new Date());
		return nowTimeStr;
	}
}
