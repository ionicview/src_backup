package com.rainbow.fw.core.factory;

import com.rainbow.fw.web.context.ContextProvider;

public class BeanFactory {
	
	public static <T> T newBean(Class<T> cls) {
		T bean = ContextProvider.getBean(cls);

		return bean;
	}

}
