package com.rainbow.fw.core.exception;

public class ExceptionMaker {

	public static void appException() {

	}

	public static void sysException() {

	}
}
