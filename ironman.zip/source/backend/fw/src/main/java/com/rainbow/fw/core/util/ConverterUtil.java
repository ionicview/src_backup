package com.rainbow.fw.core.util;

import java.lang.reflect.Field;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rainbow.fw.constant.REGEXP;

public class ConverterUtil {
	
	// string converter to google JsonObject
    public static JsonObject toJsonObject(String s){
    	
    	JsonObject jsonObject = null;
    	try{
    		jsonObject = (JsonObject) new JsonParser().parse(s);
    	}catch(Exception e){
    		return null;
    	}
	    return jsonObject;
    }

    // google JsonObject converter to Class object
    public static <T> T toObject(JsonObject jsonObject, Class<T> cls, Number initial_value){
    	
    	// check valid
    	
    	// get all field of class
    	Field fieldlist[] = cls.getDeclaredFields();
    	
    	// loop all field
    	for (Field field : fieldlist) {
    		// if the field is numberic and value of the jsonobject property is empty set the property null
    		if (field.getType().getSuperclass()!=null && field.getType().getSuperclass().equals(Number.class)){
    			String key = field.getName();
    			if (jsonObject.get(key)!=null)
				if (jsonObject.get(key).toString().isEmpty() || jsonObject.get(key).toString().equals(REGEXP.DOUBLEQUOTATION)){
    				jsonObject.remove(key);
    				jsonObject.addProperty(key, initial_value);
    			}
    		}
    		if (field.getType().getSuperclass()!=null && field.getType().getSuperclass().equals(java.util.Date.class)){
    			String key = field.getName();
    			if (jsonObject.get(key)!=null)
				if (jsonObject.get(key).toString().isEmpty() || jsonObject.get(key).toString().equals(REGEXP.DOUBLEQUOTATION)){
    				jsonObject.remove(key);
    				jsonObject.add(key, null);
    			}
    		}
    	}
    	Gson gson = new Gson();
    	T t = null;
    	try{
    		t = gson.fromJson(jsonObject, cls);
    	}catch(Exception e){
    		return null;
    	}
    	return t;
    }
}
