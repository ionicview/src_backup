package com.rainbow.fw.constant;

public class CLASSNAME {
	final public static String APACHE_BASE64 = "com.sun.org.apache.xerces.internal.impl.dv.util.Base64";
}
