package com.rainbow.fw.web.codelist;

import java.util.List;

import com.rainbow.fw.web.codelist.bean.CodeDefine;

public interface CodeListService {
	List<CodeDefine> getAllCodeList();
}
