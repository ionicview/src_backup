package com.rainbow.fw.security;

import java.lang.reflect.Method;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import com.rainbow.fw.constant.CLASSNAME;
import com.rainbow.fw.constant.FWKEYWORD;

/** 
 * 对字符串加密,加密算法使用MD5,SHA-1,SHA-256
 *  
 * @author WangGang
 */  
public class EncryptService {
	    /**
	     * 默认使用SHA-256
	     * 
	     * @param strSrc
	     *            要加密的字符串
	     * @return
	     */
	    public static String HashEncrypt(String strSrc) {
	        MessageDigest md = null;
	        String strDes = null;

	        byte[] bt = strSrc.getBytes();
	        try {
	            md = MessageDigest.getInstance(FWKEYWORD.SHA_256);
	            md.update(bt);
	            strDes = bytes2Hex(md.digest()); // to HexString
	        } catch (NoSuchAlgorithmException e) {
	            return null;
	        }
	        return strDes;
	    }

	    public static String bytes2Hex(byte[] bts) {
	        String des = "";
	        String tmp = null;
	        for (int i = 0; i < bts.length; i++) {
	            tmp = (Integer.toHexString(bts[i] & 0xFF));
	            if (tmp.length() == 1) {
	                des += "0";
	            }
	            des += tmp;
	        }
	        return des;
	    }
	    /*** 
	     * encode by Base64 
	     */  
	    public static String encodeBase64(byte[]input) throws Exception{  
	        Class clazz=Class.forName(CLASSNAME.APACHE_BASE64);  
	        Method mainMethod= clazz.getMethod(FWKEYWORD.ENCODE, byte[].class);  
	        mainMethod.setAccessible(true);  
	         Object retObj=mainMethod.invoke(null, new Object[]{input});  
	         return (String)retObj;  
	    }  
	    /*** 
	     * decode by Base64 
	     */  
	    public static byte[] decodeBase64(String input) throws Exception{  
	        Class clazz=Class.forName(CLASSNAME.APACHE_BASE64);  
	        Method mainMethod= clazz.getMethod(FWKEYWORD.ENCODE, String.class);  
	        mainMethod.setAccessible(true);  
	         Object retObj=mainMethod.invoke(null, input);  
	         return (byte[])retObj;  
	    } 
	    
	    public static String HMACSHA256(byte[] data, byte[] key) 
	    {
	          try  {
	             SecretKeySpec signingKey = new SecretKeySpec(key, FWKEYWORD.HMACSHA256);
	             Mac mac = Mac.getInstance(FWKEYWORD.HMACSHA256);
	             mac.init(signingKey);
	             return byte2hex(mac.doFinal(data));
	          } catch (NoSuchAlgorithmException e) {
	             e.printStackTrace();
	          } catch (InvalidKeyException e) {
	            e.printStackTrace();
	          }
	          return null;
	    }
	    
	    public static String byte2hex(byte[] b) 
	    {
	        StringBuilder hs = new StringBuilder();
	        String stmp;
	        for (int n = 0; b!=null && n < b.length; n++) {
	            stmp = Integer.toHexString(b[n] & 0XFF);
	            if (stmp.length() == 1)
	                hs.append('0');
	            hs.append(stmp);
	        }
	        return hs.toString().toUpperCase();
	    }
	    
	    public static String getRandomString(int length) { //length表示生成字符串的长度  
	        String base = "abcdefghijklmnopqrstuvwxyz0123456789";     
	        Random random = new Random();
	        StringBuffer sb = new StringBuffer();     
	        for (int i = 0; i < length; i++) {     
	            int number = random.nextInt(base.length());     
	            sb.append(base.charAt(number));     
	        }     
	        return sb.toString();     
	     }  
}
