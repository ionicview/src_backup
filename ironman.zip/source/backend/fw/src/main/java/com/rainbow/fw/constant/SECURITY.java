package com.rainbow.fw.constant;

public class SECURITY {
	static public int SECRET_KEY_LEN = 15;
}
