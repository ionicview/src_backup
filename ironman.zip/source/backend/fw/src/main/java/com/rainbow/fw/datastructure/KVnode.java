package com.rainbow.fw.datastructure;

import java.util.Vector;

@SuppressWarnings("hiding")
public class KVnode<K,Object>{
	long id;
	K key;
	Object value;
	KVnode<K,Object> parent;
	Vector<KVnode<K,Object>> child;
	int childLen;
	
	public KVnode(){
		id = 0;
		child = new Vector<KVnode<K,Object>>();
		parent = null;
	}

	public KVnode(K key, Object value, long id, KVnode<K,Object> parent){
		this.id = id;
		this.key = key;
		this.value = value;
		this.parent = parent;
		child = new Vector<KVnode<K,Object>>();
	}
	
	public void addChild(KVnode<K,Object> childnode){
		for(int i = 0; i < childLen; i++){
			if (child.get(i).id > childnode.id){
				child.add(i == 0 ? 0 : i - 1, childnode);
				childLen++;
				return;
			}
		}
		child.add(childnode);
		childLen++;
	}
	
	public void removeChild(KVnode<K,Object> childnode){
		child.remove(childnode);
		childLen --;
	}
	
	public void setValue(Object o){
		value = o;
	}
	
	
}
