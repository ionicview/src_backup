package com.rainbow.fw.datastructure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@SuppressWarnings("hiding")
public class KVtree<K,Object> {

	KVnode<K,Object> root;
	
	public KVtree(){
		root = new KVnode<K,Object>();
	}
	
	public void addNode(K key, Object value, long id, long parentId){
		
		KVnode<K,Object> newnode = addNode(key,value,id,parentId,root);
		if (newnode == null) {
			KVnode<K,Object> parent = new KVnode<K,Object>(null, null, parentId, null);
			newnode = new KVnode<K,Object>(key, value, id, parent);
			root.addChild(newnode);
		}
		Vector<KVnode<K,Object>> adopted = new Vector<KVnode<K,Object>>();
		for(int i = 0; i < root.childLen; i++){
			KVnode<K,Object> child = root.child.get(i);
			if (child.parent.id == id){
				adopted.add(child);
				newnode.addChild(child);
				child.parent = newnode;
			}
		}
		for(int i = 0; i < adopted.size(); i++){
			root.removeChild(adopted.get(i));
		}
	}

	private KVnode<K,Object> addNode(K key, Object value, long id, long parentId, KVnode<K,Object> node){
		
		KVnode<K,Object> newnode = null;

		// new node is a child of this node
		if (node.id == parentId){
			newnode = new KVnode<K,Object>(key, value, id, node);
			node.addChild(newnode);
		}
		else{
			for(int i = 0; i < node.childLen&&newnode==null; i++){
				newnode = addNode(key, value, id, parentId, node.child.get(i));
			}
		}
		return newnode;
	}
	
	public JsonObject toJson(KVnode<K,Object> node){
		Map<K,Object> json = new LinkedHashMap<K,Object>();
		toJson(node,json);
		return  (JsonObject) new Gson().toJsonTree(json);
	}
	
	public JSONObject toJSON(KVnode<K,Object> node){
		Map<K,Object> json = new LinkedHashMap<K,Object>();
		toJson(node,json);
		return  new JSONObject(json);
	}
	
	
	@SuppressWarnings("unchecked")
	private void toJson(KVnode<K,Object> node, Map<K,Object> json){
		
		if (node.childLen == 0){
			json.put(node.key, node.value);
		}
		else{
			if (node.key == null || node.key.toString().isEmpty()){
				
				List<JsonObject> list = new ArrayList<JsonObject>();
				json.put(node.key, (Object) list);
				for(int i = 0; i < node.childLen; i++){
					Map<K,Object> childjson = new LinkedHashMap<K,Object>();
					toJson(node.child.get(i), childjson);
				}
			}
			else{
				Map<K,Object> childjson = new LinkedHashMap<K,Object>();
				json.put(node.key, (Object) childjson);
				for(int i = 0; i < node.childLen; i++){
					toJson(node.child.get(i), childjson);
				}
			}
		}
	}
	
	public KVnode<K,Object>  node(K key){
		return node(key, root);
	}
	
	public KVnode<K,Object>  node(List<K> keyList){
		return node(keyList, root, 0);
	}
	
	private KVnode<K,Object>  node(List<K> keyList, KVnode<K,Object> node, int index){

		KVnode<K,Object> pinggonode = null;
		for(int i = 0; i < node.childLen && pinggonode == null; i++){
			if (keyList.get(index).equals(node.child.get(i).key)){
				if (index == keyList.size() - 1)
					return node.child.get(i);
				else
					pinggonode =  node(keyList, node.child.get(i), ++index);
			}
		}
		return pinggonode;
	}
	
	private KVnode<K,Object>  node(K key, KVnode<K,Object> node){
		
		KVnode<K,Object> pinggonode = null;
		if (key.equals(node.key))
			pinggonode =  node;
		else{
			for(int i = 0; i < node.childLen&&pinggonode==null; i++){
				pinggonode = node(key, node.child.get(i));
			}
		}
		return pinggonode;
	}
	
	public KVnode<K,Object>  node(int id){
		return node(id, root);
	}
	
	private KVnode<K,Object>  node(int id, KVnode<K,Object> node){
		KVnode<K,Object> pinggonode = null;
		if (node.id == id)
			pinggonode =  node;
		else{
			for(int i = 0; i < node.childLen; i++){
				pinggonode = node(id, node.child.get(i));
			}
		}
		return pinggonode;
	}
	
	//sales_detail_setting.settings.columns.vendor.config.list
	
}
