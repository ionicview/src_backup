import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

export const routes: Routes = [
  // { path: '', redirectTo: 'pages', pathMatch: 'full' },
  // { path: '**', redirectTo: 'pages/dashboard' }
  // { path: '', redirectTo: 'pages/login', pathMatch: 'full' },
  // { path: '**', redirectTo: 'pages/dashboard' }

  {
    path: '',
    loadChildren: 'app/pages/login/login.module#LoginModule',
    pathMatch: 'full'
  },
  { path: '**', redirectTo: 'pages/home' }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
