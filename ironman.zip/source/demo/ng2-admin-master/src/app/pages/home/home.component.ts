import {Component} from '@angular/core';
import { PurchaseService } from './component/purchase.service';

@Component({
  selector: 'home',
  templateUrl: './home.html',
  styleUrls: ['./home.scss']

})
export class Home {
  //采购模块-会计总信息
  purchaseData:Array<any>;
  //采购模块-采购总信息
  purchaseData2:Array<any>;
  //流水账总信息
  journalAccountData:Array<any>;
  //销售总信息
  sellData:Array<any>;
  //费用总信息
  costData:Array<any>;
  //库存总信息
  repertoryData:Array<any>;


  constructor(private _purchaseService: PurchaseService) {
    this.purchaseData = _purchaseService.purchaseData;
    this.purchaseData2 = _purchaseService.purchaseData2;

    this.journalAccountData = _purchaseService.journalAccountData;
    this.sellData = _purchaseService.sellData;
    this.costData = _purchaseService.costData;
    this.repertoryData = _purchaseService.repertoryData;
  }
  
}
