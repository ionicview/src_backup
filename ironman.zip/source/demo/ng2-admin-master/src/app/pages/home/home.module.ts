import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgaModule } from '../../theme/nga.module';
import { Todo } from './todo';
import { Calendar } from './calendar';

import { CalendarService } from './calendar/calendar.service';
import { TodoService } from './todo/todo.service';
import { PurchaseService } from './component/purchase.service';

import { routing } from './home.routing';
import { Home } from './home.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    CKEditorModule,
    routing
  ],
  declarations: [
    Todo,
    Calendar,
    Home
  ],
  providers: [
    CalendarService,
    TodoService,
    PurchaseService
  ]
})
export class HomeModule {
}
