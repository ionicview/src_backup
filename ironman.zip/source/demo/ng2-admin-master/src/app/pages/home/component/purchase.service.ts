import { Injectable } from '@angular/core';

@Injectable()
export class PurchaseService {

  constructor() { }

  //采购模块-会计总信息
  purchaseData = [
    {
      arrears: '10,392',
      arrearsNotTax: '23,983',
      receivable: '24,696.32',
    }
  ];
  //采购模块-采购总信息
  purchaseData2 = [
    {
      arrears: '112,344',
      receivable: '1,456,796.32',
    }
  ];

  //流水账总信息
  journalAccountData = [
    {
      overallBalance: '14,567,964,345.54',
    }
  ];

    //采购总信息
    sellData = [
    {
      name: '张会计',
      receivable: '45,344',
      receivableNotTax: '78,765',
      invoicePay: '1,895,796.31',
    },
    {
      name: '李会计',
      receivable: '67,451',
      receivableNotTax: '96,235',
      invoicePay: '4,344,567.31',
    }

  ];

  //费用总信息
  costData = [
    {
      loanSum: '743,132.13',
      costSum: '764,378.98',
    }
  ];
  //库存总信息
  repertoryData = [
    {
      repertoryNum: '140000',
      repertorySum: '7,964,345.54',
    }
  ];

}
