import {Injectable} from '@angular/core';
import {BaThemeConfigProvider} from '../../../theme';

@Injectable()
export class CalendarService {

  constructor(private _baConfig:BaThemeConfigProvider) {
  }

  getData() {

    let dashboardColors = this._baConfig.get().colors.dashboard;
    return {
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      defaultDate: '2017-03-08',
      selectable: true,
      selectHelper: true,
      editable: true,
      eventLimit: true,
      events: [
        {
          title: '给打款',
          start: '2017-03-01',
          color: dashboardColors.silverTree
        },
        {
          title: '发货周期',
          start: '2017-03-07',
          end: '2017-03-10',
          color: dashboardColors.blueStone
        },
        {
          title: '小张休息',
          start: '2017-03-14',
          color: dashboardColors.surfieGreen
        },
        {
          title: '收货款',
          start: '2017-04-01',
          color: dashboardColors.gossip
        }
      ]
    };
  }
}
