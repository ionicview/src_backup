import {Injectable} from '@angular/core';

@Injectable()
export class TodoService {

  private _todoList = [
    { text: '星期一给张力发货' },
    { text: '星期二给王三打款' },
    { text: '星期三给张力开发票' },
    { text: '星期四小牛休息' },
    { text: '星期五钢材要进点货' },
  ];

  getTodoList() {
    return this._todoList;
  }
}
