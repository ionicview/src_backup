import { Routes, RouterModule } from '@angular/router';

import { Charge } from './charge.component';

import { SalerChargeList } from './components/salerChargeList/salerCharge.component';
import { CustomerChargeList } from './components/customerChargeList/customerCharge.component';
import { UsageChargeList } from './components/usageChargeList/usageCharge.component';

const routes: Routes = [
  {
    path: '',
    component: Charge,
    children: [
      { path: 'salerChargeList', component: SalerChargeList},
      { path: 'customerChargeList', component: CustomerChargeList},
      { path: 'usageChargeList', component: UsageChargeList },
      { path: '', redirectTo: 'salerChargeList', pathMatch: 'full' }
    ]
  }
];

export const routing = RouterModule.forChild(routes);
