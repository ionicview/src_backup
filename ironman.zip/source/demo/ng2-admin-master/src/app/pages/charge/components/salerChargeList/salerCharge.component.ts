import {Component} from '@angular/core';

@Component({
  selector: 'saler-charge-list',
  templateUrl: './salerCharge.html'
})
export class SalerChargeList {
  constructor() {
  }
}
