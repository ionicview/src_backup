import {Component} from '@angular/core';

@Component({
  selector: 'customer-charge-list',
  templateUrl: './customerCharge.html'
})
export class CustomerChargeList {
  constructor() {
  }
}
