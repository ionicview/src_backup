import {Component} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'saler-charge-table',
  templateUrl: './salerChargeTable.html'
})
export class SalerChargeTable {

  charges : any;
  constructor(private router : Router) {
      this.charges = [
        {
            no : "20160908",
            saler : "王一",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
        {
            no : "20160908",
            saler : "王二",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
        {
            no : "20160908",
            saler : "王三",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
      ];
  }

  goCustomerList(){
    this.router.navigate(['pages/charge/customerChargeList']);
  }
}
