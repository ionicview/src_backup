import {Component} from '@angular/core';

@Component({
  selector: 'usage-charge-list',
  templateUrl: './usageCharge.html'
})
export class UsageChargeList {
  constructor() {
  }
}
