import {Component} from '@angular/core';

@Component({
  selector: 'usage-charge-table',
  templateUrl: './usageChargeTable.html'
})
export class UsageChargeTable {

  charges : any;
  constructor() {
      this.charges = [
        {
            no : "1",
            usage : "邮费",
            maker : "长商",
            amount : "234"
        },
        {
            no : "2",
            usage : "邮费",
            maker : "长商",
            amount : "234"
        },
        {
            no : "3",
            usage : "邮费",
            maker : "长商",
            amount : "234"
        },

      ];
  }
}
