import {Component} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'customer-charge-table',
  templateUrl: './customerChargeTable.html'
})
export class CustomerChargeTable {

  charges : any;
  constructor(private router : Router) {
      this.charges = [
        {
            no : "20160908",
            customer : "张译",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
        {
            no : "20160908",
            customer : "章二",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
        {
            no : "20160908",
            customer : "章三",
            expenses : "3243",
            operatingPayment : "234234",
            remark : "没什么特别的"
        },
      ];
  }
  goUsageList(){
      this.router.navigate(['pages/charge/usageChargeList']);
  }
}
