import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgaModule } from '../../theme/nga.module';

import { routing } from './charge.routing';
import { Charge } from './charge.component';

import { SalerChargeList } from './components/salerChargeList/salerCharge.component';
import { SalerChargeTable } from './components/salerChargeList/components/salerChargeTable/salerChargeTable.component';
import { CustomerChargeList } from './components/customerChargeList/customerCharge.component';
import { CustomerChargeTable } from './components/customerChargeList/components/customerChargeTable/customerChargeTable.component';
import { UsageChargeList } from './components/usageChargeList/usageCharge.component';
import { UsageChargeTable} from './components/usageChargeList/components/usageChargeTable/usageChargeTable.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    CKEditorModule,
    routing
  ],
  declarations: [
    Charge,
    SalerChargeList,
    SalerChargeTable,
    CustomerChargeList,
    CustomerChargeTable,
    UsageChargeList,
    UsageChargeTable
  ]
})
export class ChargeModule {
}
