import {Component} from '@angular/core';

@Component({
  selector: 'charge',
  template: `<router-outlet></router-outlet>`
})
export class Charge {
  constructor() {
  }
}
