package com.github.jhonnymertz.wkhtmltopdf.wrapper.page;

public enum PageType {
    htmlAsString,
    url,
    file
}
